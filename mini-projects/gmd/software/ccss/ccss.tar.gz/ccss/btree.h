#ifndef BTREE_H
#define BTREE_H 1

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <malloc.h>
#include <errno.h>
#include <assert.h>
#include "datatype.h"

void alloc_data(tree_t *t, int nelems, int order, int ksize);

/*    Search functions that take a key and the tree to search for that
 * key in.   They return the index to that key if the key is found,
 * and -1 if the key isn't found. 
 *    The _tree_bN_search() functions are a optimized functions that
 * will only work on trees with N keys per node,
 * _tree_bgeneral_search() will work on any tree but will have a
 * higher instruction count than an optimized function. */
int _tree_b8_search(xkey_t, tree_t *);
int _tree_b4_search(xkey_t, tree_t *);
int _tree_b2_search(xkey_t, tree_t *);
int _tree_bgeneral_search(xkey_t, tree_t *);

/* functions to fill the tree with data. */
void reorder(data_t *src, tree_t *targ);
void _reorder(data_t *, tree_t *, int *, int);
void tree_fill(tree_t *targ, int incr);
void _tree_fill(tree_t *targ, int incr, xkey_t *k, int node);
void _set(data_t*, xkey_t, int);

int xkeycharncmp(xkey_t, char*, int);
void xstrncpy(char*, char*, int);

#endif
