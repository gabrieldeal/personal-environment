#include "btree.h"

void
alloc_data(t, nelems, order, ksize)
	tree_t *t;
	int	nelems,
			order,
			ksize;
{
	int	cnt;

	t->num_elements = nelems;
	t->levels = (log(nelems) / log(order + 1));
	t->order = order;
	t->key_size = ksize;

	if(nelems % order != 0)
		nelems += order - (nelems % order);

	t->real_num_elements = nelems;

	t->data = (data_t *) malloc(sizeof(data_t) * nelems * ksize);
	if(! t->data)
	{
		perror("alloc_data() error:  malloc() failed, ");
		exit(1);
	}

	/* put the "highest" element here so the search will continue
	 * down if it is searching an incomplete node (the last one).
	 * this intruduces a bug... if 0xff isn't in the tree, i have
	 * just added it in... i guess that's life.   the moral of the
	 * story is perhaps that the number of data elements ought always
	 * be a factor of 'ksize' or that 0xffff...fff should never be in
	 * the input data set.
	 * 
	 * i ought to set these high elements after I've filled the tree,
	 * so it can be something in the tree... */
	cnt = t->real_num_elements * ksize;
	while(cnt > t->num_elements * ksize)
	{
		*(t->data + cnt - 1) = (char)0xff;
		cnt--;
	}
}


int
_tree_b8_search(key, tree)
	register xkey_t	key;
	tree_t *tree;
{
	register int	node,
						cmp,
						size;

	size = tree->key_size;
	node = 1;

	while(node <= tree->num_elements)
	{
		cmp = LD_CMP(key, tree->data + size * (2 + node), size);
		if(cmp < 0) /* x 0 .. 2 x */
		{	cmp = LD_CMP(key, tree->data + size * node, size);
			if(cmp < 0) /* x 0 x */
			{	cmp = LD_CMP(key, tree->data + size * (- 1 + node), size);
				if(cmp < 0) /* left of 0 */
					node += node << 3;
				else if(cmp == 0) /* hit on 0 */
					return node;
				else /* right of 0 */
					node += (node + 1) << 3;
			}
			else if(cmp == 0) /* hit on 1 */
				return node + 1;
			else /* x 2 x */
			{	cmp = LD_CMP(key, tree->data + size * (1 + node), size);
				if(cmp < 0) /* left of 2 */
					node += (node + 2) << 3;
				else if(cmp == 0) /* hit on 2 */
					return node + 2;
				else /* right of 2 */
					node += (node + 3) << 3;
			}
		}
		else if(cmp == 0) /* hit on 3 */
			return node + 3;
		else /* x 4 .. 7 x */
		{	cmp = LD_CMP(key, tree->data + size *(4 + node), size);
			if(cmp < 0) /* x 4 x */
			{	cmp = LD_CMP(key, tree->data + size *(3 + node), size);
				if(cmp < 0) /* left of 4 */
					node += (node + 4) << 3;
				else if(cmp == 0)
					return node + 4;
				else
					node += (node + 5) << 3;
			}
			else if(cmp == 0) /* hit on 5 */
				return node + 5;
			else /* x 6 7 x */
			{	cmp = LD_CMP(key, tree->data + size * (5 + node), size);
				if(cmp > 0) /* x 7 x */
				{	cmp = LD_CMP(key, tree->data + size * (6 + node), size);
					if(cmp < 0) /* left of 7 */
						node += (node + 7) << 3;
					else if(cmp == 0) /* hit on 7 */
						return node + 7;
					else /* right of 7 */
						node += (node + 8) << 3;
				}
				else if(cmp == 0) /* hit on 6 */
					return node + 6;
				else /* left of 6 */
					node += (node + 6) << 3;
			}	
		}
	}

	return -1;
}

int
_tree_b4_search(key, tree)
	xkey_t	key;
	tree_t	*tree;
{
	register int	node,
						cmp;

	node = 1;

	while(node <= tree->num_elements)
	{
		cmp = LT_CMP(key, tree, 2 - 1 + node);
		if(cmp < 0) /* x 0 1 x */
		{
			cmp = LT_CMP(key, tree, 1 - 1 + node);
			if(cmp < 0) /* x 0 x */
			{
				cmp = LT_CMP(key, tree, -1 + node);
				if(cmp < 0) /* left of 0 */
					node += 4 * node;
				else if(cmp == 0) /* hit on 0 */
					return node;
				else /* right of 0 */
					node += 4 * (node + 1);
			}
			else if(cmp == 0) /* hit on 1 */
				return node + 1;
			else /* right of 1 */
				node += 4 * (node + 2);
		}
		else if(cmp == 0) /* hit on 2 */
			return node + 2;
		else /* x 3 x */
		{
			cmp = LT_CMP(key, tree, 2 + node);
			if(cmp < 0) /* left of 3 */
				node += 4 * (node + 3);
			else if(cmp == 0) /* hit on 3 */
				return node + 3;
			else /* right of 3 */			
				node += 4 * (node + 4);
		}
	}

	return -1;
}

int
_tree_b2_search(key, tree)
	xkey_t	key;
	tree_t	*tree;
{
	int	cmp,
			node;

	node = 1;

	while(node <= tree->num_elements)
	{
		cmp = LT_CMP(key, tree, node - 1);
		if(cmp > 0)
		{
			cmp = LT_CMP(key, tree, node);
			if(cmp < 0) /* middle */
				node = node * 3 + 2;
			else if(cmp > 0) /* right */
				node = node * 3 + 4;
			else /* hit right */
				return node + 1;
		}
		else if(cmp < 0) /* left */
			node = node * 3;
		else /* hit left */
			return node;
	}

	return -1;
}

int
_tree_bgeneral_search(key, tree)
	xkey_t	key;
	tree_t	*tree;
{
	int	cmp,
			node;
	int	b_mid,
			b_hi,
			b_lo;

	node = 1;

	while(node <= tree->num_elements)
	{
		/* do a binary search on this group of keys */
		b_hi = node + tree->order - 2;
		b_lo = node - 1;
		do
		{
			b_mid = (b_lo + b_hi) >> 1;
			cmp = LT_CMP(key, tree, b_mid);
			if(cmp > 0)
				b_lo = b_mid + 1;
			else if(cmp < 0)
				b_hi = b_mid - 1;
			else
				return b_mid + 1;
		}
		while(b_hi >= b_lo);

		/* take the correct branch to the next node */
		if(cmp < 0)
			node = node + tree->order * (b_mid + 1);
		else
			node = node + tree->order * (b_mid + 2);
	}

	return -1;
}



/* fill the tree with the sorted data in 'src' */
void
reorder(src, targ)
	data_t	*src;
	tree_t	*targ;
{
	int	i_ptr;

	i_ptr = 0;
	_reorder(src, targ, &i_ptr, 1);
}
void
_reorder(src, targ, i_ptr, node)
	data_t	*src;
	tree_t	*targ;
	int	*i_ptr,
			node;
{
	int	kids,
			cnt,
			stop;

	if(node > targ->num_elements)
		return;

	if(targ->num_elements - node + 1 < targ->order)
		stop = targ->num_elements - node + 1;
	else
		stop = targ->order;

	kids = node * (targ->order + 1);
	for(cnt = 0 ; cnt < stop ; cnt++)
	{
		_reorder(src, targ, i_ptr, kids + cnt * targ->order);
		TD_COPY(targ, node + cnt - 1, src + (*i_ptr) * targ->key_size);
		(*i_ptr)++;
	}
	_reorder(src, targ, i_ptr, kids + cnt * targ->order);
}


/* Fill 'targ' with integers starting at 0 and incrementing by 'incr',
 * in the b-heap format. */
void
tree_fill(targ, incr)
	tree_t	*targ;
	int	incr;
{
	xkey_t	k;

	k.hi = k.lo = 0L;
	_tree_fill(targ, incr, &k, 1);
}
void
_tree_fill(targ, incr, k_ptr, node)
	tree_t	*targ;
	int	incr;
	xkey_t	*k_ptr;
	int	node;
{
	int	kids,
			cnt,
			stop;

	if(node > targ->num_elements)
		return;

	if(targ->num_elements - node + 1 < targ->order)
		stop = targ->num_elements - node + 1;
	else
		stop = targ->order;

	kids = node * (targ->order + 1);
	for(cnt = 0 ; cnt < stop ; cnt++)
	{
		_tree_fill(targ, incr, k_ptr, kids + cnt * targ->order);
		_set(DATA_AT(targ, node + cnt - 1), *k_ptr, targ->key_size);
		k_ptr->hi = k_ptr->lo = k_ptr->lo + incr;
	}
	_tree_fill(targ, incr, k_ptr, kids + cnt * targ->order);
}
/* This is BROKEN for key_size > 16 st. key_size % 8 != 0. */
void
_set(targ, src, key_size)
	data_t	*targ;
	xkey_t	src;
	int	key_size;
{
	int	j;

	assert(key_size <= 16);

	j = key_size - 1;
	for( ; j >= 8 ; j--)
		targ[j] = (data_t) ((src.hi >> ((j - 8) * 8)) & 0xff);
	for( ; j >= 0 ; j--)
		targ[j] = (data_t) ((src.lo >> (j * 8)) & 0xff);
	
}


/*
 * Same as strncpy(), I was having problems with strncpy() not copying
 * all the bits.
 *
 * (I should have used memcpy().) */
void
xstrncpy(a, b, n)
	char	*a,
			*b;
	register int	n;
{
	for(n-- ; n >= 0 ; n--)
	{
		a[n] = b[n];
	}
}

int
xkeycharncmp(a, b, size)
	xkey_t	a;
	char	*b;
	int	size;
{
	int	shift;

	assert(size <= 16);

	shift = 0;
	size--;
	shift = size * 8;

	for( ; size >= 8 ; shift -= 8, size--)
	{
		if((0xff & (int)b[size]) != ((int)(a.hi >> shift) & 0xff))
		{
			return ((int) ((a.hi >> shift) & 0xff)) - (0xff & (int)b[size]);
		}
	}
	for( ; size >= 0 ; shift -= 8, size--)
	{
		if((0xff & (int)b[size]) != ((int)(a.lo >> shift) & 0xff))
		{
			return ((int) ((a.lo >> shift) & 0xff)) - (0xff & (int)b[size]);
		}
	}

	return 0;
}

