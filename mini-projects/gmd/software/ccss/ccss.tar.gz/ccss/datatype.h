#ifndef DATATYPE_H
#define DATATYPE_H 1

#ifdef SOLARIS
	typedef long long xlong;
#else
	typedef long xlong;
#endif

/* this is a kludge because at one point i was concerned about getting
 * the search key into registers... i don't care anymore but don't want
 * to go back and modify the code so it is allocated from the heap. */
typedef struct _bigint
{
	xlong	hi,
			lo;
} xkey_t;

typedef char data_t;
typedef struct _tree_t
{
	data_t	*data;
	long	num_elements,
			real_num_elements;
	int	levels,
			order,
			key_size;	
} tree_t;

/* adjust 'index' so it points to the 'index'th group of key_size */
#define INDEX(tree, index) \
	((index) * (tree)->key_size)

/* return address of data in 'tree' at 'index' */
#define DATA_AT(tree, index) \
	((tree)->data + INDEX(tree, index))

/* DD == Data to Data
 * DT == Data to Tree
 * TT == Tree to Tree
 * LT == Long to Tree
 * etc. */
#define TD_COPY(tree, i, src)	\
	(xstrncpy(DATA_AT(tree, i), src, (tree)->key_size))
#define LD_CMP(lng, data, size) \
	(xkeycharncmp(lng, data, size))
#define LT_CMP(lng, tree, i) \
	LD_CMP(lng, DATA_AT(tree, i), (tree)->key_size)


#endif

