#!/usr/local/bin/perl5 -w


for $i (0 .. 25)
{
	print +(2**$i - 20) . ":";
}

# 
# for $i (0 .. 10)
# {
# 	$base = (8*((9**($i+1) - 1)/8));
# 	print "$base:";
# 	foreach $j (1 .. 3)
# 	{
# 		$incr = (8*(9**($i + 1)))*($j/4);
# 		print +($base + $incr) . ":";
# 	}
# 
# # }