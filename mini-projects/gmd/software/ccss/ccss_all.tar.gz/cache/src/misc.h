#ifndef MISC_H
#define MISC_H 1


#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include "datatype.h" 
#include "assert.h"

void swap(data_t *a, data_t *b);

void xstrncpy(char *, char *, int);
int xstrncmp(char *, char *, int);
xlong chartolong(char *, int);
int charlongncmp(char *, xlong, int);
int xkeycharncmp(xkey_t, char *, int);
void fill_random(data_t *, int, int);
void random_accesses(tree_t *, int);

void linear_reset();
int linear_accesses(data_t *, int, int, int);
void treeprint(tree_t *, int);
void arrayprint(data_t *, int, int);
void fill_even(data_t *, int, int);
void set(data_t *targ, xkey_t src, int key_size);

void print_slice(data_t *, int, int, int, int);
void tprint(tree_t *, int, int);
void xprint(char *, int);
int read_input(int *, char *, char *);

#endif


