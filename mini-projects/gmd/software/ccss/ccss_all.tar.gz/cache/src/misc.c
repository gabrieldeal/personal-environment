#include "misc.h"
#include "utils.h"
#include <string.h>
#include <errno.h>


void swap(data_t *a, data_t *b)
{
	data_t	tmp;

	if(a == b)
	{
		return;
	}
	tmp = *a;
	*a = *b;
	*b = tmp;
}


/*
 * Same as strncpy(), I was having problems with strncpy() not copying
 * all the bits.
 *
 * (I should have used memcpy().) */
void
xstrncpy(a, b, n)
	char	*a,
			*b;
	register int	n;
{
	for(n-- ; n >= 0 ; n--)
	{
		a[n] = b[n];
	}
}

/*
 * Convert the char starting at *src and ending at *(src + size - 1)
 * into a long, and return that value.
 * trusting that size <= 8. */
xlong
chartolong(src, size)
	char	*src;
	int	size;
{
	xlong	retval;
	int	shift;

	retval = 0;
	for(size--, shift = size * 8 ; size >= 0 ; size--, shift -= 8)
	{
		retval += (0xff & (int)src[size]) << shift;
	}
	return retval;
}


/*
 * Compare the long 'b' with the first 'size' chars in 'a',
 * return -1 if a < b, 0 if a == b, and 1 if a > b.
 *	I'm trusting that size <= 8.
 */
int
charlongncmp(a, b, size)
	char	*a;
	xlong	b;
	int	size;
{
	int	shift;

	fprintf(stderr, "You're using this?\n");
	exit(1);

	shift = 0;

	for(size--, shift = size * 8 ; size >= 0 ; shift -= 8, size--)
	{
		if((0xff & (int)a[size]) != ((int)(b >> shift) & 0xff))
		{
			return (0xff & (int)a[size]) - ((int) ((b >> shift) & 0xff));
		}
	}

	return 0;
}

int
xkeycharncmp(a, b, size)
	xkey_t	a;
	char	*b;
	int	size;
{
	int	shift;

	assert(size <= 16);

	shift = 0;
	size--;
	shift = size * 8;

	for( ; size >= 8 ; shift -= 8, size--)
	{
		if((0xff & (int)b[size]) != ((int)(a.hi >> shift) & 0xff))
		{
			return ((int) ((a.hi >> shift) & 0xff)) - (0xff & (int)b[size]);
		}
	}
	for( ; size >= 0 ; shift -= 8, size--)
	{
		if((0xff & (int)b[size]) != ((int)(a.lo >> shift) & 0xff))
		{
			return ((int) ((a.lo >> shift) & 0xff)) - (0xff & (int)b[size]);
		}
	}

	return 0;
}

/*
 * Same as strncmp().   I don't remember why I rewrote this,
 * maybe for performance? or was strncmp() not using the high order
 * bits?
 *
 * so it doesn't compare for the NULL end of the string, maybe?
 */
int
xstrncmp(a, b, size)
	char	*a,
			*b;
	int	size;
{
	for(size-- ; size >= 0 ; size--)
	{
		if(a[size] != b[size])
		{
			return (0xff & (int)a[size]) - (0xff & (int)b[size]);
		}
	}

	return 0;
}



void
treeprint(tree_t *tree, int node)
{
	int	kids,
			cnt;

	if(node > tree->num_elements)
	{
		return;
	}	

	kids = node * (tree->order + 1);
	for(cnt = 0 ; cnt < tree->order ; cnt++)
	{
		treeprint(tree, kids + cnt * tree->order);
		printf("tree ");
		xprint(DATA_AT(tree, node + cnt - 1), tree->key_size);
		printf("\n");
	}
	treeprint(tree, kids + cnt * tree->order);
}

void
arrayprint(data_t *array, int keysize, int top)
{
	int	cnt;

	for(cnt = 0 ; cnt < top ; cnt++)
	{
		printf("array ");
		xprint(array + cnt * keysize, keysize);
		printf("\n");
	}
}

/*
 * Fill data[] with the even numbers in the range [0, num_elements).
 *
 * Allowing 16-byte keys complicates things.   As a kind of kludge to
 * make this at least partially sane, i'm making the upper bytes
 * duplicates of the corresponding lower 8 bytes.   I hope this is a
 * sensible thing to do.   Things this simplifies is writing my own
 * addition code for 16-byte integers, and it makes it so I don't have
 * to generate different numbers to search for based on the size of
 * the key. */
void
fill_even(data, key_size, num_elements)
	data_t	*data;
	int	key_size,
			num_elements;
{
	long	i;
	xkey_t	k;

	assert(key_size <= 16);

	/* This is:   2 * (num_elements - 1)  >  (2^(key_size * 8)) - 1   
	 * And certainly i hope i can assume i will never use a data set
	 * greater or equal to 2^64 - 1 (although i really wouldn't mind
	 * having access to all that RAM :). */
	if(key_size < 8 && ((xlong)2 * (((xlong)num_elements - (xlong)1))) > (((xlong)1 << ((xlong)key_size * (xlong)8)) - (xlong)1))
	{
		fprintf(stderr, 
			"\nWarning:  this key size (%i) is too small to hold the largest number in the search data set (%i).\n\n", 
			key_size, 
			2 * (num_elements - 1)
		);
	}

	for(i = 0 ; i < num_elements ; i++)
	{
		k.hi = k.lo = i*2;
		set(&data[i*key_size], k, key_size);
/*		j = key_size - 1;
		for( ; j >= 8 ; j--)
			data[i*key_size + j] = (data_t) (((i * 2) >> ((j - 8) * 8)) & 0xff);
		for( ; j >= 0 ; j--)
			data[i*key_size + j] = (data_t) (((i * 2) >> (j * 8)) & 0xff);
*/			
	}
}

/* This is BROKEN for key_size > 16 st. key_size % 8 != 0. */
void
set(targ, src, key_size)
	data_t	*targ;
	xkey_t	src;
	int	key_size;
{
	int	j;

	assert(key_size <= 16);

	j = key_size - 1;
	for( ; j >= 8 ; j--)
		targ[j] = (data_t) ((src.hi >> ((j - 8) * 8)) & 0xff);
	for( ; j >= 0 ; j--)
		targ[j] = (data_t) ((src.lo >> (j * 8)) & 0xff);
	
}

void
fill_random(data_t *data, int key_size, int num_elements)
{
	int	i;

	fprintf(stderr, "fill_random() needs to be updated.\n");
	exit(1);

	for(i = key_size * num_elements - 1 ; i >= 0 ; i--)
	{
		data[i] = get_random_char();
	}
}

/* access last element in the line so the instrumentation
 * routines will catch it. */
int linearindex = -1;
void
linear_reset(void)
{
	linearindex = -1;
}
int
linear_accesses(flusher, num_elements, num_accesses, line_size)
	data_t	*flusher;
	int	num_elements,
			num_accesses,
			line_size;
{
	int	count;

	count = 0;
	while(num_accesses > 0)
	{
		linearindex += line_size;
		if(flusher[linearindex] == (char)num_accesses)
			count++;

		num_accesses--;
		if(linearindex >= num_elements)
			linearindex = linearindex % num_elements;
	}
	return count;
}
void
random_accesses(tree, num_accesses)
	tree_t	*tree;
	int	num_accesses;
{
	int	index1,
			index2;

	while(num_accesses-- > 0)
	{
		index1 = get_rand_int(tree->num_elements);
		index2 = get_rand_int(tree->num_elements);

		TT_CMP(tree, index1, index2);
	}
}


void
xprint(a, n)
	char	*a;
	int	n;
{
	int x;
	for(x = 0 ; x < n ; x++)
		printf("%c", *(a + x));
}


void
tprint(t, lo, hi)
	tree_t	*t;
	int	lo,
			hi;
{
	int	i,
			j;

	for(i = lo ; i <= hi ; i++)
	{
		for(j = 0 ; j < t->key_size ; j++)
		{
			printf("%c", t->data[t->key_size * i + j]);
		}
		printf(" ");
	}
}

