#include "defs.h"
#include "misc.h"


#define PROGNAME	"btree"
#define ARGS "n:l:o:k:s:S:m:M:L:c:f:vtChO:F:j:g"

#define USAGE	"\
-n num_elements -l number-levels -t -C [-o order]\n\
             [-k key-bytes] [-s seed] [-S num-searches] [-m flush-freq]\n\
             [-M flush-num] [-L logfile] [-c comment] [-v] [-f r|e] [-h]\n\
             [-O number] [ -F flush-size ] [ -j cache-line-size ]\
             [-g]\
-v ... verbosity \
-h ... this message \
-g ... use the general search function\
"

void register_address(long, long, int, char *);
int atom_ccbsearch(tree_t *, tree_t *, int, int, int, int, int);
int atom_bsearch(tree_t *, tree_t *, int, int, int, int, int);
int real_bsearch(tree_t *, tree_t *, int, int, int, int, int);

/*
 * calls to this function are intercepted by Atom to get the memory
 * addresses that it should pay attention to.
 */
void
register_address(start, offset, ksize, name)
	long	start,
			offset;
	int	ksize;
	char	*name;
{
	printf("please don't optimize me out compiler!\n");
}

enum Type { TREE, ARRAY };

/* the array and tree search functions, i made the array one a 
 * pointer just in case the overhead is higher. 
 * they're global just because i'm lazy. */
int (*afun)(xkey_t, data_t *, int, int, int);
int (*tfun)(xkey_t, tree_t *); 

int
main(argc, argv)
 int	argc;
 char	**argv;
{
	tree_t/*	tree,*/
				worker,
				flusher,
				array;
	float		t_over_a,
				t,
				a;
	int	levels,
			i,
			line_size,
			seed,
			order,
			num_searches,
			acount,
			tcount,
			error,
			key_size,
			num_elements,
			flush_freq,
			flush_number,
			verbose,
			trad_search,
			ccb_search,
			flush_size,
			odds,
			gsearch_flag;
	char	arg,
			*def_comment = "(none)",
			*def_logfile = "/dev/null";
	FILE	*fh;

	/* since the members of struct timeval are ints on Digital Unix and
	 * longs under Solaris, I'm just casting them all to longs when
	 * there may be problems. */
	struct timeval	bef, /* 1 microsecond = 1/1,000,000 seconds */
						aft, 
						adiff, 
						tdiff;
	char	*log_file,
			*comment,
			fill_type;

	/* assignments to data_t depends on this. */
	assert(sizeof(xlong) == 8);

	/************* process options **************/

	afun = _array_b_search;
	tcount = acount = 0;

	flush_size = 4194304; /* 4194304 = 4 * 2^20, 2097152 = 2 * 2^20 */
	odds = 2;
	seed = 0;
	num_elements = 0;
	line_size = 32;
	levels = 0;
	order = 8;
	tfun = _tree_b8_search;
	key_size = 4;
	num_searches = 1000000;
	flush_freq = 0;
	flush_number = 0;
	log_file = NULL;
	comment = def_comment;
	verbose = 0;
	trad_search = 0;
	ccb_search = 0;
	fill_type = 'e';
	error = 0;
	gsearch_flag = 0;
	while(! error && (arg = getopt(argc, argv, ARGS)) != -1)
	{
		switch(arg)
		{
			case 'O':
				odds = atoi(optarg);
				break;
			case 'h':
				fprintf(stderr, "Usage: %s %s\n", PROGNAME, USAGE);
				exit(0);
			case 'F':
				flush_size = atoi(optarg);
				break;
			case 'f':
				fill_type = *optarg;
				break;
			case 'n':
				num_elements = atoi(optarg);
				break;
			case 'j':
				line_size = atoi(optarg);
				break;
			case 'l':
				levels = atoi(optarg);
				break;
			case 'g':
				gsearch_flag = 1;
				break;
			case 'o':
				order = atoi(optarg);
				switch(order)
				{
					case 2:
						tfun = _tree_b2_search;
						break;
					case 4:
						tfun = _tree_b4_search;
						break;
					case 8:
						tfun = _tree_b8_search;
						break;
					default:
						gsearch_flag = 1;
						tfun = _tree_bgeneral_search; /* done again below... */
						break;
				}
				break;
			case 'k':
				key_size = atoi(optarg);
				break;
			case 's':
				seed = atoi(optarg);
				break;
			case 'S':
				num_searches = atoi(optarg);
				break;
			case 'm':
				flush_freq = atoi(optarg);
				break;
			case 'M':
				flush_number = atoi(optarg);
				break;
			case 'L':
				log_file = optarg;
				break;
			case 'c':
				comment = optarg;
				break;
			case 't':
				trad_search = 1;
				break;
			case 'C':
				ccb_search = 1;
				break;
			case 'v':
				verbose = 1;
				break;
			default:
				error = 1;
				/* getopt() takes care of printing this error message */
				break;
		}
	}
	if(gsearch_flag)
		tfun = _tree_bgeneral_search;
	if(error == 1)
		fprintf(stderr, "Error processing options\n");

	if(line_size <= 0)
	{
		error = 1;
		fprintf(stderr, "Line size (-j) must be > 0.\n");
	}
	if(flush_size < 0)
	{
		error = 1;
		fprintf(stderr, "Flush size (-F) must be >= 0.\n");
	}
	if(key_size <= 0)
	{
		error = 1;
		fprintf(stderr, "Key size (-k) must be > 0.\n");
	}
	if(order <= 0)
	{
		error = 1;
		fprintf(stderr, "Order (-o) must be > 0.\n");
	}
	if(num_elements <= 0 && levels <= 0)
	{
		error = 1;
		fprintf(stderr, "Must specify positive number of levels (-l) or elements\n");
	}
	if(trad_search == 0 && ccb_search == 0)
	{
		error = 1;
		fprintf(stderr, "Must specify at least one of -t or -C\n");
	}
	if(fill_type != 'r' && fill_type != 'e')
	{
		error = 1;
		fprintf(stderr, "Fill type (-f) must be r (random) or e (even).\n"); 
	}

	if(error == 1)
	{
		fprintf(stderr, "Usage: %s %s\n", PROGNAME, USAGE);
		exit(1);
	}


	if(levels == 0)
		levels = 1 + (int) (log(num_elements) / log(order + 1));

	if(log_file == NULL)
		log_file = def_logfile;
	if(num_elements == 0)
		num_elements = pow(order + 1, levels) - 1;
	fh = fopen(log_file, "a");
	if(fh == NULL)
	{
		fprintf(stderr, "Can't open %s", log_file);
		perror(NULL);
		exit(1);
	}

	if(flush_freq == 0)
		flush_number = 0;

	if(verbose)
	{
		printf("* elements %i levels %i order %i key size %i seed %i\n",
			num_elements,
			levels,
			order,
			key_size,
			seed
		);
		printf("* flush_freq %i flush_num %i log file %s comment %s\n",
				flush_freq,
				flush_number,
				log_file,
				comment
		);
		printf("* fill type %c searches %i trad search %i cc search %i\n", 
			fill_type,
			num_searches,
			trad_search,
			ccb_search
		);
		printf("* line_size %i flush_size %i odds %i\n",
			line_size,
			flush_size,
			odds
		);
	}

	/************ create the data to be searched ***************/

	if(verbose)
	{
		printf("Allocating data...\n");
		fflush(stdout);
	}
	alloc_data(&flusher, flush_size, 1, 1); 
	alloc_data(&worker, flush_size, 1, 1); 
	alloc_data(&array, num_elements, order, key_size);
/*	alloc_data(&tree, num_elements, order, key_size);*/

	/* register the most-used one first */
	register_address(
		(long) array.data, 
		(long) array.key_size * array.num_elements, 
		array.key_size,
		"array"
	);
	register_address(
		(long) worker.data, 
		(long) worker.key_size * worker.num_elements,
		array.key_size, /*worker.key_size,*/
		"worker"
	);

	if(fill_type == 'r')
	{
		srand(seed);
		if(verbose) 
		{
			printf("Filling with random data...\n");
			fflush(stdin);
		}
		fill_random(array.data, array.key_size, array.num_elements);
		if(verbose) 
		{
			printf("Sorting data...\n");
			fflush(stdin);
		}
		quick_sort(&array, 0, num_elements - 1);
	}
	else
	{
		if(verbose)
		{
			printf("Filling with contiguous even data...\n");
			fflush(stdin);
		}
		fill_even(array.data, array.key_size, array.num_elements);
	}

	/************ run the searches ****************/

	if(trad_search)
	{
		if(verbose)
		{
			printf("flushing array...");
			fflush(stdout);
		}
		for(i = 1 ; i < flusher.num_elements ; i++)
		{
			if(TT_CMP(&flusher, i, i - 1) == 0)
			{
				acount++;
			}
		}
		if(verbose)
		{
			printf("done with %i matches.\n", acount);
			fflush(stdout);
		}
		srand(3 * seed);
		if(verbose)
		{
			printf("Searching array %i times...", num_searches);
			fflush(stdout);
		}
		gettimeofday(&bef, NULL);
		acount = atom_bsearch(
						&worker,
						&array, 
						num_searches, 
						flush_freq,
						flush_number,
						odds,
						line_size
					);
		gettimeofday(&aft, NULL);
		adiff = sub_time(aft, bef);
		if(verbose)
		{
			printf("%7i matches in %3li sec %7li usec\n", 
					acount, 
					(long) adiff.tv_sec, 
					(long) adiff.tv_usec
			);
			fflush(stdout);
		}
	}
	else
	{
		adiff.tv_sec = -1;
		adiff.tv_usec = -1;
	}

	if(ccb_search)
	{
		srand(3 * seed);
		/*
		 * some of the tree could still be in the cache if 'num_elements'
		 * is small.
		 */
		if(verbose)
		{
			printf("copying tree into array area...");
			fflush(stdout);
		}

		if(verbose)
		{
			printf("Filling tree...\n");
			fflush(stdin);
		}
	/*	reorder(array.data, &tree);*/
		tree_fill(&array, 2);

/*		memcpy(array.data, tree.data, tree.num_elements * tree.key_size);*/

		if(verbose)
		{
			printf("done.\n");
			fflush(stdout);
		}

		if(verbose)
		{
			printf("flushing tree...");
			fflush(stdout);
		}
		for(i = 1 ; i < flusher.num_elements ; i++)
		{
			if(TT_CMP(&flusher, i, i - 1) == 0)
			{
				tcount++;
			}
		}
		if(verbose)
		{
			printf("done with %i matches.\n", tcount);
			fflush(stdout);
		}

		if(verbose)
		{
			printf("Searching tree  %i times...", num_searches);
			fflush(stdout);
		}
		gettimeofday(&bef, NULL);
		tcount = atom_ccbsearch(
						&worker,
						&array,
						num_searches, 
						flush_freq,
						flush_number,
						odds,
						line_size
					);
		gettimeofday(&aft, NULL);
		tdiff = sub_time(aft, bef);
		if(verbose)
		{
			printf("%7i matches in %3li sec %7li usec\n", 
					tcount, 
					(long) tdiff.tv_sec, 
					(long) tdiff.tv_usec
			); 
			fflush(stdout);
		}
		if(trad_search && acount != tcount)
		{
			fprintf(stderr, "Hits not equal (%i != %i)\n", acount, tcount);
			exit(1);
		}
	}
	else
	{
		tdiff.tv_sec = -1;
		tdiff.tv_usec = -1;
	}

	/************** output **************/

	if(trad_search && ccb_search)
	{
		t = (tdiff.tv_sec + tdiff.tv_usec / 1000000.0);
		a = (adiff.tv_sec + adiff.tv_usec / 1000000.0);
		if(a == 0)
		{
			t_over_a = -1;
		}
		else
		{
			t_over_a =  t / a;
		}
	}
	else
	{
		t_over_a = -1;
	}

	fprintf(fh, "numelements %i levels %i order %i keysize %i seed %i ",
		num_elements, 
		levels, 
		order, 
		key_size, 
		seed
	);
	fprintf(fh, "searches %i hits %i flush_number %i flush_freq %i ", 
		num_searches, 
		acount,
		flush_number,
		flush_freq
	);

/*	fprintf(fh, "array %li %li ", (long) adiff.tv_sec, (long) adiff.tv_usec);
	fprintf(fh, "tree %li %li ", (long) tdiff.tv_sec, (long) tdiff.tv_usec);
*/

	fprintf(fh, 
		"array %f ", 
		((long) adiff.tv_sec * 1000000 + (long) adiff.tv_usec) / (float) num_searches
	);
	fprintf(fh, 
		"tree %f ", 
		((long) tdiff.tv_sec * 1000000 + (long) tdiff.tv_usec) / (float) num_searches
	);
	fprintf(fh, "t/a %f comment (%s) general %s\n", 
		t_over_a, 
		comment,
		(gsearch_flag ? "isgeneral" : "notgeneral")
	);

	if(verbose)
	{
		printf("tree/array time ratio %f\n", t_over_a);
		fflush(stdout);
	}

/*	free(tree.data);*/
	free(array.data);
	free(flusher.data);
	free(worker.data);
	return 0;
}

int
real_search(worker, array, num_searches, flush_freq, flush_number, odds, t, line_size)
	tree_t	*worker,
				*array;
	int	num_searches,
			flush_freq,
			flush_number,
			odds;
	enum Type	t;
	int	line_size;
{
	int	i,
			tmp,
			flush,
			count;
	xlong register	datum;
	xkey_t	b_datum;

	flush = count = 0;

	linear_reset();
	for(i = 1 ; i <= num_searches ; i++)
	{
		if(flush_freq > 0 && (++flush % flush_freq) == 0)
		{
			linear_accesses(
				worker->data,
				worker->num_elements * worker->key_size, 
				flush_number,
				line_size
			);
		}
		/* get a number within the range [0 .. 2 * num_elements) */
		datum = get_rand_int((array->num_elements - 1) * 2);
		/* make the number even */
		datum = (datum / odds) * odds;
		b_datum.hi = b_datum.lo = datum;
		switch(t)
		{
			case TREE:
				tmp = tfun(b_datum, array);
				break;
			case ARRAY:
				tmp = afun(
							b_datum, 
							array->data, 
							0, 
							array->num_elements - 1, 
							array->key_size
						);
				break;
			default:
				fprintf(stderr, "Error:  real_search() bad type.\n");
				exit(1);
				break;
		}
		if(tmp >= 0)
			count++;
	}
	return count;
}

/*
 *	run 'num_searches' searches, return the number of hits.
 */
int
atom_bsearch(worker, array, num_searches, flush_freq, flush_number, odds, line_size)
	tree_t	*worker,
				*array;
	int	num_searches,
			flush_freq,
			flush_number,
			odds,
			line_size;
{
	return real_search(worker, array, num_searches, flush_freq, flush_number, odds, ARRAY, line_size);
}


/*
 *	run 'num_searches' searches, return the number of hits.
 */
int
atom_ccbsearch(worker, tree, num_searches, flush_freq, flush_number, odds, line_size)
	tree_t	*worker,
				*tree;
	int	num_searches,
			flush_freq,
			flush_number,
			odds,
			line_size;
{
	return real_search(worker, tree, num_searches, flush_freq, flush_number, odds, TREE, line_size);
}




/*	if(verbose)
	{
		printf("Checking array order...\n");
		fflush(stdin);
	}
	for(i = 0 ; i < num_elements ; i++)
	{
		if(i > 0 && TT_GT(&array, i-1, i))
		{
			printf("\nACK %i %i ", i, i-1);
			ltmp = 0xff & array.data[i*key_size];
			ltmp += 0xff00 & ((long)array.data[i*key_size + 1] << 8);
			ltmp += 0xff0000 & ((long)array.data[i*key_size + 2] << 16);
			ltmp += 0xff000000 & ((long)array.data[i*key_size + 3] << 24);
			printf("  %i: %lu ", i, ltmp);
			i--;
			ltmp = 0xff & array.data[i*key_size];
			ltmp += 0xff00 & ((long)array.data[i*key_size + 1] << 8);
			ltmp += 0xff0000 & ((long)array.data[i*key_size + 2] << 16);
			ltmp += 0xff000000 & ((long)array.data[i*key_size + 3] << 24);
			printf(" %i: %lu ", i, ltmp);
			tprint(&array, i - 1, i);
			printf(" line %i\n", __LINE__);
			exit(1);
		}
	}
	if(verbose)
	{
		printf("Checking tree order...\n");
		fflush(stdout);
	}
	for(i = 1 ; i <= num_elements ; i++)
	{
		if(i > 1)
		{
			m = t2a(i - 1, tree.levels, tree.order) - 1;
			n = t2a(i, tree.levels, tree.order) - 1;
			if(TT_GT(&tree, m, n))
			{
				printf("\nACK i == %i, %i: %lu, %i: %lu, levels %i\n", 
					i,
					m, 
					chartolong(DATA_AT(&tree, m), tree.key_size),
					n,
					chartolong(DATA_AT(&tree, n), tree.key_size),
					tree.levels
				);
				exit(1);
			}

		}
	}
*/







