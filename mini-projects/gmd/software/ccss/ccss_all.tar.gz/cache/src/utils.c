#include "utils.h"
#include <errno.h>



struct timeval sub_time(struct timeval a, struct timeval b)
{
	struct timeval	ret_val;

	ret_val.tv_sec = a.tv_sec - b.tv_sec;
	ret_val.tv_usec = a.tv_usec - b.tv_usec;

	if(ret_val.tv_usec < 0)
	{
		ret_val.tv_sec--;
		ret_val.tv_usec += 1000000;
	}

	return ret_val;
}

void *xmalloc(size_t n, char *filename, int line)
{
	void	*buf;

	errno = 0;
	buf = malloc(n);
	if(buf == NULL)
	{
		fprintf(stderr, "%s line %i: xmalloc(%lu) failed.\n", filename, line, (ulong) n);
		perror(NULL);
		exit(-1);
	}

	return buf;
}


int get_rand_int(int max)
{
	return (int) (((double)rand()) / RAND_MAX * (max));
}

char *get_random_string(int min_size, int max_size)
{
	int	size,
			i;
	char	*string;

	if(min_size > max_size)
	{
		fprintf(stderr, "get_random_string(%i, %i) error:  min_size > max_size\n", min_size, max_size);
		return NULL;
	}

	size = min_size + get_rand_int(max_size - min_size);
	string = (char *) xmalloc(sizeof(char) * size, __FILE__, __LINE__);

	for(i = size - 1 ; i >= 0 ; i--)
	{
		*(string + i) = get_random_char();
	}

	return string;
}


/*	ASCII values 32 - 126 are all printable */
char get_random_char()
{
	/* just a-z */
/*	return (char) (97 + get_rand_int(122 - 97));*/


	/*	all printables */
	return (char) (32 + get_rand_int(126 - 32));

}


