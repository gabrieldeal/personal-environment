#include <sys/mman.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "adefs.h"


/* a cache line */
struct Tag 
{
	long tag;
	long valid;
} cache[CACHE_SIZE >> BLOCK_SHIFT];

/* the data structure for storing cache statistics */
int	next_free_range = 0;
struct Addr_range
{
	long	start,
			end;
	uint	flag,
			key_size;
	ulong	misses[NUM_SLOTS],
			hits[NUM_SLOTS];
	char	*name;
#ifdef MAP
	int	map[REF_NUM_MAX];
#endif
} c_stats[NUM_RANGES];
	
#ifdef MAP
	FILE	*ref_fd = NULL;
	char	ref_file_buf[BUFSIZE];
#endif

#ifdef DUMP
	char	dump_buf[BUFSIZE];
	FILE	*dump_fd = NULL;
#endif

char	log_file_buf[BUFSIZE];
char	*num_elements,
		*num_searches,
		*flush_num,
		*flush_freq,
		*key_size,
		*order,
		*general_flag,
		*nullstr = "(NULL)";
FILE	*log_fd = NULL;
ulong	instructions[NUM_SLOTS],
		num_calls[NUM_SLOTS],
		resets = 0;
int	enable_flag = 0,
		verbose;

/*********************************************************************/


/* Search for the range containing this address, return -1 if no
 * such range exists. */
int
locate_addr_range(addr)
	long	addr;
{
	int	range;

	for(range = 0 ; range < NUM_RANGES ; range++)
	{
		if(! c_stats[range].flag)
			continue;

		if(c_stats[range].start <= addr && c_stats[range].end > addr)
			return range;
	}

	return -1;
}


long	arraystart = 0;


/*
 * References to addresses outside of the range
 * [start, start + offset) will be ignored by reference(). */
void
register_address(start, offset, ksize, name)
	long	start,
			offset;
	int	ksize;
	char	*name;
{
	int	range,
			slot;

	if(strcmp(name, "array") == 0)
		arraystart = start;

	if(DEBUG)
	{
		fprintf(stderr, 
			"got %s start %li, offset %li, total-size %li, key-size %i\n", 
			name,
			start, 
			offset,
			start + offset,
			ksize
		);
	}

	range = next_free_range++;
	if(range >= NUM_RANGES)
	{
		fprintf(stderr, "Error: register_address() too many ranges used.\n");
		exit(1);
	}

printf("Range %s, start %li, offset %li, ksize %i\n", name, start, offset, ksize);
	c_stats[range].flag = 1;
	c_stats[range].start = start;
	c_stats[range].end = start + offset;
	c_stats[range].key_size = ksize;
	c_stats[range].name = strdup(name);

	for(slot = 0 ; slot < NUM_SLOTS ; slot++)
		c_stats[range].misses[slot] = c_stats[range].hits[slot] = 0;
}

void
reset_cache(void) 
{
	int index; 
#ifdef MAP
	long	range;

	for(range = 0 ; range < NUM_RANGES ; range++)
	{
		for(index = 0 ; index < REF_NUM_MAX ; index++)
			c_stats[range].map[index] = 0;
	}
#endif

	resets++;
	for (index = 0 ; index < (CACHE_SIZE >> BLOCK_SHIFT) ; index++) 
		cache[index].valid = 0;
}


/* Instead of command line parameters, the atom code gets
 * parameters via environment variables.   Use these to 
 * initialize the analysis routines. */
void
initialize(void)
{
	char	*string;
	int	i,
			j;

	reset_cache();

	for(i = 0 ; i < NUM_RANGES ; i++)
	{
		c_stats[i].flag = 0;
#ifdef MAP
		for(j = 0 ; j < REF_NUM_MAX ; j++)
			c_stats[i].map[j] = 0;
#endif
	}

	general_flag = getenv("ATOM_GENERAL");
	NULL_FIX(general_flag);
	num_elements = getenv("ATOM_NUM_ELEMENTS");
	NULL_FIX(num_elements);
	num_searches = getenv("ATOM_NUM_SEARCHES");
	NULL_FIX(num_searches);
	flush_num = getenv("ATOM_FLUSH_NUM");
	NULL_FIX(flush_num);
	flush_freq = getenv("ATOM_FLUSH_FREQ");
	NULL_FIX(flush_freq);
	key_size = getenv("ATOM_KEY_SIZE");
	NULL_FIX(key_size);
	order = getenv("ATOM_ORDER");
	NULL_FIX(order);

	string = getenv("ATOM_VERBOSE");
	if(string != NULL)
		verbose = atoi(string);
	else
		verbose = 0;

#ifdef DUMP
	string = getenv("ATOM_DUMP_FILE");
	if(string != NULL)
		dump_fd = fopen(string, "w");
	else
	{
		if(verbose)
			fprintf(stderr, "DUMP_FILE is /dev/null\n");
		dump_fd = fopen("/dev/null", "w");
	}
	assert(dump_fd != NULL);
	setbuffer(dump_fd, dump_buf, BUFSIZE);
#endif

	string = getenv("ATOM_LOG_FILE");
	if(string != NULL)
		log_fd = fopen(string, "a");
	else
	{
		if(verbose)
			fprintf(stderr, "LOG_FILE is /dev/null\n");
		log_fd = fopen("/dev/null", "a");
	}
	assert(log_fd != NULL);
	setbuffer(log_fd, log_file_buf, BUFSIZE);

#ifdef MAP
	string = getenv("ATOM_REF_FILE");
	if(string != NULL)
		ref_fd = fopen(string, "w");
	else
	{
		if(verbose)
			fprintf(stderr, "ref_file is /dev/null\n");
		ref_fd = fopen("/dev/null", "w");
	}
	assert(ref_fd != NULL);
	setbuffer(ref_fd, ref_file_buf, BUFSIZE);
#endif

}

void
close_file(void)
{
	fclose(log_fd);
#ifdef DUMP
	fclose(dump_fd);
#endif
#ifdef MAP
	fclose(ref_fd);
#endif
}
	
void
reset_slot(slot)
	int	slot;
{
	int	range;

	SLOT_CHECK(slot);

	instructions[slot] = 0;
	num_calls[slot] = 0;
	for(range = 0 ; range < NUM_RANGES ; range++)
		c_stats[range].misses[slot] = c_stats[range].hits[slot] = 0;
}

void
count_calls(slot)
	int	slot;
{
	SLOT_CHECK(slot);

	num_calls[slot]++;
}
void
enable(void)
{
	enable_flag = 1;
}
void
disable(void)
{
	enable_flag = 0;
}

void
reference(address, procname)
	long	address;
	char	*procname;
{
	int	index,
			range,
			slot;
	long	tag;
	long	ref_index,
			ref_first;

	ref_first = ((arraystart + 32) & (CACHE_SIZE-1)) >> BLOCK_SHIFT;

	if(enable_flag == 0)
		return;

	/* just recording it for the first address range we find (i'm
	 * trying to keep it from being too slow). */
	range = locate_addr_range(address);
	if(range < 0)
		return;

#ifdef REF_MAP
	ref_index = address - c_stats[range].start;
	if((ref_index + 1) % c_stats[range].key_size == 0)
	{
		ref_index = ((ref_index + 1) / c_stats[range].key_size) - 1;
		if(ref_index >= REF_NUM_MAX)
		{
			fprintf(stderr, 
				"Warning:  referenced address (%li) in range %s > REF_NUM_MAX (%i).\n",
				ref_index,
				c_stats[range].name,
				REF_NUM_MAX
			);
		} 
		else
			c_stats[range].map[ref_index]++;
	}
#endif

	index = (address & (CACHE_SIZE-1)) >> BLOCK_SHIFT;
	tag = address >> BLOCK_SHIFT;

	if(cache[index].valid == 0 || cache[index].tag != tag)
	{
		if(DEBUG)
			fprintf(stderr, "m-%s %i\n", procname, index);
		for(slot = 0 ; slot < NUM_SLOTS ; slot++)
			c_stats[range].misses[slot]++;
		cache[index].tag = tag;
		cache[index].valid = 1;
#ifdef MISS_MAP
/*	ref_index = address - c_stats[range].start;
if(index == ref_first)
	printf("Miss on ZERO by %s at line #%li\n", c_stats[range].name, ref_index);
	if(ref_index < REF_NUM_MAX)
	{
if(index == ref_first)
	printf("XXMiss on ZERO by %s at ref_index %li value %i range %i\n", c_stats[range].name, ref_index, c_stats[range].map[ref_index], range);
		c_stats[range].map[ref_index]++;
	}
	else
		printf(".");
*/
	ref_index = address - c_stats[range].start;
	if((ref_index + 1) % c_stats[range].key_size == 0)
	{
		ref_index = ((ref_index + 1) / c_stats[range].key_size) - 1;
		if(ref_index >= REF_NUM_MAX)
		{
			fprintf(stderr, 
				"Warning:  referenced address (%li) in range %s > REF_NUM_MAX (%i).\n",
				ref_index,
				c_stats[range].name,
				REF_NUM_MAX
			);
		} 
		else
			c_stats[range].map[ref_index]++;
	}
#endif
	} 
	else
	{
		if(DEBUG)
			fprintf(stderr, "h-%s %i\n", procname, index);
		for(slot = 0 ; slot < NUM_SLOTS ; slot++)
			c_stats[range].hits[slot]++;
	}
}

void
instruction(num)
	int	num;
{
	int	slot;

	if(enable_flag == 0)
		return;

	for(slot = 0 ; slot < NUM_SLOTS ; slot++)
		instructions[slot] += num;
}

void
set_resets(i)
	int	i;
{
	resets = i;
}

void
dump_results(name, slot)
	char	*name;
	int	slot;
{
#ifdef DUMP
	int	range;

	SLOT_CHECK(slot);

	for(range = 0 ; range < NUM_RANGES ; range++)
	{
		if(! c_stats[range].flag)
			continue;

		fprintf(dump_fd,
			"%s %s references %lu misses %lu hits %lu instructions %lu\n", 
			name,
			c_stats[range].name,
			c_stats[range].misses[slot] + c_stats[range].hits[slot],
			c_stats[range].misses[slot],
			c_stats[range].hits[slot],
			instructions[slot]
		);
	}
#endif
}

void
print_ref_results(range_name, id)
	char	*range_name,
			*id;
{
#ifdef MAP
	long	n;
	int	range;

	for(range = 0 ; range < NUM_RANGES ; range++)
	{
		if(strcmp(c_stats[range].name, range_name) == 0)
			break;
	}
	if(range >= NUM_RANGES)
	{
		fprintf(stderr, "Couldn't find range '%s'.\n", range_name);
		return;
	}
	for(
/*		n = c_stats[range].key_size - 1 ;
		n < REF_NUM_MAX && n < c_stats[range].end - c_stats[range].start ;
		n += c_stats[range].key_size
*/
		n = 0 ;
		n < REF_NUM_MAX && n * c_stats[range].key_size < c_stats[range].end - c_stats[range].start ;
		n++
	)
	{
		fprintf(ref_fd, 
			"%s %s %li %i\n", 
			range_name,
			id,
/*			(n + 1) / c_stats[range].key_size,*/
			n,
			c_stats[range].map[n]
		);
		if(ferror(ref_fd))
		{
			fprintf(stderr, "Error printing to ref_fd.\n");
			perror(NULL);
			break;
		}
	}
#endif 
}

void
print_short_results(pname, slot, newline, match)
	char	*pname;
	int	slot,
			newline;
	char	*match;
{
	int	range,
		flag;
	float	hits,
		misses;

	SLOT_CHECK(slot);

	flag = 0;
	for(range = 0 ; range < NUM_RANGES ; range++)
	{
		if(! c_stats[range].flag)
			continue;
		else
			flag = 1;

		if(strcmp(c_stats[range].name, match) != 0)
			continue;

		misses = c_stats[range].misses[slot];
		hits = c_stats[range].hits[slot];
		fprintf(log_fd,
			"%s %s elms %s s %s ref %f mis %f instr %f keysize %s order %s flfreq %s flnum %s general %s %s",
			pname,
			c_stats[range].name,
			num_elements,
			num_searches,
			(misses + hits) / ((float) num_calls[slot]),
			misses / ((float) num_calls[slot]), 
			instructions[slot] / ((float) num_calls[slot]),
			key_size,
			order,
			flush_freq,
			flush_num,
			general_flag,
			(newline == 1 ? "\n" : " ")
		);
	}

	if(verbose && ! flag)
		fprintf(stderr, "No ranges defined!\n");
}


void printstr(char *s)
{
	printf("%s\n", s);
}

