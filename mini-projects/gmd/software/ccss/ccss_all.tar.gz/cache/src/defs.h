#ifndef DEFS_H
#define DEFS_H	1

#include <stdlib.h>
#include <unistd.h> /* getopt() */
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include "misc.h"
/*#include "map.h"*/
#include "datatype.h"
#include "quick_sort.h"
#include "btree.h"
#include "array_b_search.h"
#include "utils.h"

#endif
