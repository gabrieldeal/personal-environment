#include "quick_sort.h"
#include "utils.h"

void _q_sort(tree_t *a, int lo, int hi, int cutoff);
int _median(int a, int b, int c);


data_t	*tmp,
			*key;
int	int_tmp;

#define MEDIAN(a,b,c) ((a)<(b)?(b)<(c)?(b):(a)<(c)?(c):(a):(b)>(c)?(b):(a)<(c)?(a):(c))

void _i_sort(tree_t *tree, int lo, int hi)
{
	int	i,
			j;

	for(i = lo + 1 ; i <= hi ; i++)
	{
		DT_COPY(tmp, tree, i);
		for(j = i ; j > lo && DT_LT(tmp, tree, j-1) ; j--)
		{
			TT_COPY(tree, j, j-1);
		}
		TD_COPY(tree, j, tmp);
	}
}

void quick_sort(tree_t *t, int lo, int hi)
{
	tmp = xmalloc(sizeof(data_t) * t->key_size, __FILE__, __LINE__);
	key = xmalloc(sizeof(data_t) * t->key_size, __FILE__, __LINE__);
	_q_sort(t, lo, hi, 10);
	_i_sort(t, lo, hi);
	free(tmp);
	free(key);
}

void _q_sort(tree_t *tree, int lo, int hi, int cutoff)
{
	int	mid,
			tmplo,
			tmphi;

	while(hi - lo > cutoff)
	{
		mid = (hi + lo) >> 1;
		mid = MEDIAN(((lo + mid) >> 1), (mid), ((hi + mid) >> 1));
		DT_COPY(key, tree, mid);
		TT_COPY(tree, mid, hi);
		TD_COPY(tree, hi, key);
	
		tmplo = lo - 1;
		tmphi = hi;

		for(;;)
		{
			while(TD_LT(tree, ++tmplo, key))
				;
			while(tmphi > tmplo && TD_GT(tree, --tmphi, key))
				;
			if(tmplo < tmphi)
			{
				DT_COPY(tmp, tree, tmplo);
				TT_COPY(tree, tmplo, tmphi);
				TD_COPY(tree, tmphi, tmp);
			}
			else
			{
				break;
			}
		}
	
		DT_COPY(tmp, tree, tmphi);
		TD_COPY(tree, tmphi, key);
		TD_COPY(tree, hi, tmp);

		if(tmphi - 1 - lo < hi - tmphi - 1)
		{
			_q_sort(tree, lo, tmphi - 1, cutoff);
			lo = tmphi + 1;
		}
		else
		{
			_q_sort(tree, tmphi + 1, hi, cutoff);
			hi = tmphi - 1;
		}
	}
}

