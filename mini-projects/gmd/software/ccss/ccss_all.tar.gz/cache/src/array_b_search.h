#ifndef B_SEARCH_H
#define B_SEARCH_H 1

#include <stdio.h>
#include <strings.h>
#include "datatype.h"
#include "misc.h"

int _array_b_search(xkey_t, data_t *, int, int, int);
int array_b_search(xkey_t, data_t *, int, int, int);

#ifndef TRUE
	#define TRUE 1
#endif
#ifndef FALSE
	#define FALSE 0
#endif

#endif
