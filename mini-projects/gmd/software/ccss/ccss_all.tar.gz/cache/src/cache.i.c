#include <stdio.h>
#include <strings.h>
#include "instrument.h"
#include "adefs.h"

int Instrument(void)
{
	Proc *proc;
	Block *block;
	Inst *inst;

	AddCallProto("initialize()");
	AddCallProto("close_file()");

	AddCallProto("reference(VALUE, char*)");
	AddCallProto("instruction(int)");

	AddCallProto("reset_cache()");
	AddCallProto("reset_slot(int)");

	AddCallProto("set_resets(int)");
	AddCallProto("count_calls(int)");

	AddCallProto("enable()");
	AddCallProto("disable()");

	AddCallProto("print_short_results(char*, int, int, char*)");
#ifdef DUMP
	AddCallProto("dump_results(char*, int)");
#endif
#ifdef MAP
	AddCallProto("print_ref_results(char*, char*)");
#endif
	AddCallProto("register_address(long, long, int, char *)");

	AddCallProto("printstr(char*)");


	AddCallProgram(ProgramBefore, "disable");
	AddCallProgram(ProgramBefore, "set_resets", 0);
	AddCallProgram(ProgramBefore, "initialize");

	AddCallProgram(ProgramAfter, "close_file");
	
	/* Slot usage
			slot 0	array: count calls, total stats
			slot 1	tree: count calls, total stats
			slot 2	array: dump
			slot 3	tree: dump
	*/
	for(proc = GetFirstProc() ; proc != NULL ; proc = GetNextProc(proc)) 
	{
		if(ProcName(proc) == NULL)
			continue;

		if(strncmp(ProcName(proc), "register_address", 14) == 0)
		{
			ReplaceProcedure(proc, "register_address");
			continue;
		}

		if(strcmp(ProcName(proc), "atom_bsearch") == 0)
		{
			AddCallProc(proc, ProcBefore, "enable");
			AddCallProc(proc, ProcBefore, "reset_cache");
			AddCallProc(proc, ProcBefore, "reset_slot", 0);
			AddCallProc(proc, ProcBefore, "reset_slot", 1);
			AddCallProc(proc, ProcBefore, "reset_slot", 2);
			AddCallProc(proc, ProcBefore, "reset_slot", 3);
#ifdef DUMP
			AddCallProc(proc, ProcAfter, "dump_results", ProcName(proc), 0);
#endif
#ifdef MAP
			AddCallProc(proc, ProcAfter, "print_ref_results", "array", "trad");
			AddCallProc(proc, ProcAfter, "print_ref_results", "worker", "trad");
#endif
			AddCallProc(proc, ProcAfter, "print_short_results", "Trad", 0, 0, "array");
			AddCallProc(proc, ProcAfter, "print_short_results", "Trad", 0, 0, "worker");
			AddCallProc(proc, ProcAfter, "disable");
		}
		else if(strcmp(ProcName(proc), "atom_ccbsearch") == 0)
		{
			AddCallProc(proc, ProcBefore, "enable");
			AddCallProc(proc, ProcBefore, "reset_cache");
			AddCallProc(proc, ProcBefore, "reset_slot", 0);
			AddCallProc(proc, ProcBefore, "reset_slot", 1);
			AddCallProc(proc, ProcBefore, "reset_slot", 2);
			AddCallProc(proc, ProcBefore, "reset_slot", 3);
#ifdef DUMP
			AddCallProc(proc, ProcAfter, "dump_results", ProcName(proc), 1);
#endif
#ifdef MAP
			AddCallProc(proc, ProcAfter, "print_ref_results", "array", "CCSS");
			AddCallProc(proc, ProcAfter, "print_ref_results", "worker", "CCSS");
#endif
			AddCallProc(proc, ProcAfter, "print_short_results", "CCSS", 1, 0, "array");
			AddCallProc(proc, ProcAfter, "print_short_results", "CCSS", 1, 1, "worker");
			AddCallProc(proc, ProcAfter, "disable");
		}
		else if(strcmp(ProcName(proc), "_array_b_search") == 0)
		{
			AddCallProc(proc, ProcBefore, "count_calls", 0);
			for(block = GetFirstBlock(proc) ; block != NULL ; block = GetNextBlock(block)) 
			{
				AddCallBlock(block, BlockBefore, "instruction", GetBlockInfo(block, BlockNumberInsts));
			}
#ifdef DUMP
			AddCallProc(proc, ProcAfter, "dump_results", ProcName(proc), 2);
			AddCallProc(proc, ProcAfter, "reset_slot", 2);
#endif
		}
		else if(
			strcmp(ProcName(proc), "_tree_b4_search") == 0
			|| strcmp(ProcName(proc), "_tree_b8_search") == 0
			|| strcmp(ProcName(proc), "_tree_b2_search") == 0
			|| strcmp(ProcName(proc), "_tree_bgeneral_search") == 0
		)
		{
			AddCallProc(proc, ProcBefore, "count_calls", 1);
			for(block = GetFirstBlock(proc) ; block != NULL ; block = GetNextBlock(block)) 
			{
				AddCallBlock(block, BlockBefore, "instruction", GetBlockInfo(block, BlockNumberInsts));
			}
#ifdef DUMP
			AddCallProc(proc, ProcAfter, "dump_results", ProcName(proc), 3);
			AddCallProc(proc, ProcAfter, "reset_slot", 3);
#endif
		}
		else if(
			strncmp(ProcName(proc), "strn", 4) == 0
			|| strncmp(ProcName(proc), "strc", 4) == 0
			|| strncmp(ProcName(proc), "xstr", 4) == 0
			|| strncmp(ProcName(proc), "strn", 4) == 0
			|| strncmp(ProcName(proc), "xkeychar", 8) == 0
			|| strncmp(ProcName(proc), "linear_ac", 8) == 0
		)
		{
			for(block = GetFirstBlock(proc) ; block != NULL ; block = GetNextBlock(block)) 
			{
				AddCallBlock(block, BlockBefore, "instruction", GetBlockInfo(block, BlockNumberInsts));
				for(inst = GetFirstInst(block) ; inst != NULL ; inst = GetNextInst(inst)) 
				{
					if(IsInstType(inst, InstTypeLoad) || IsInstType(inst, InstTypeStore)) 
					{
						AddCallInst(inst, InstBefore, "reference", EffAddrValue, ProcName(proc));
					}
				}
			}
		}
	}

	return 0;
}

