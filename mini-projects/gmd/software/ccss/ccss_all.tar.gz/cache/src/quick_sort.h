#ifndef BINARY_SORT_H
#define BINARY_SORT_H 1

#include <stdio.h>
#include <string.h>
#include "datatype.h"

void quick_sort(tree_t *array, int lo, int hi);

#endif

