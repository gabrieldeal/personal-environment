#include "array_b_search.h"


int
_array_b_search(key, array, lo, hi, size)
	register xkey_t	key;
	data_t	*array;
	register int	lo,
						hi,
						size;
{
	register int	mid,
						top,
						cmp;

	top = hi;

	while(hi >= lo)
	{
		mid = (lo + hi) / 2;
		cmp = LD_CMP(key, array + mid * size, size);
		if(cmp > 0)
		{
			lo = mid + 1;
		}
		else if(cmp == 0)
		{
			return mid;
		}
		else /* cmp < 0 */
		{
			hi = mid - 1;
		}
	}

	return -1;
}


/*   BROKEN, using GT, CMP
int
_array_bx_search(key, array, lo, hi, size)
	xkey_t	key;
	data_t	*array;
	int	hi,
			lo,
			size;
{
	register int	mid,
						top;

	top = hi;

	while(hi != lo)
	{
		mid = (lo + hi) / 2;
		if(GT(key, array + mid * size, size))
		{
			lo = mid + 1;
		}
		else
		{
			hi = mid;
		}
	}

	if(CMP(key, array + hi * size, size) == 0)
	{
		return hi;
	}
	else
	{
		return -1;
	}
}
*/

int
array_b_search(key, array, lo, hi, size)
	xkey_t	key;
	data_t	*array;
	int	lo,
			hi,
			size;
{
	int	retval;

	retval = _array_b_search(key, array, lo, hi, size);

	if(retval > hi)
	{
		return -1;
	}
	else if(retval != -1)
	{
		return retval;
	}
	else
	{
		return retval;
	}
}
