#ifndef DATATYPE_H
#define DATATYPE_H 1

/* xlong is only for the use of variables that are compared to data_t
 * types or places where it is obvious i need 8-byte values
 * (in fill_even()). */
#ifdef SOLARIS_2_5_1
	/*		death to old 32-bit OS's (we all ought to upgrade
	 * to Solaris 7).
	 *		"long long" is 8 bytes under Solaris 2.5.1,
	 * "long" is 4 bytes.	 And i'll just have to deal
	 * with the compiler warnings about the use of long long. */
	typedef long long xlong;
#else /* Digital Unix */
	typedef long xlong;
#endif

typedef struct _bigint
{
	xlong	hi,
			lo;
} xkey_t;


typedef char data_t;
typedef struct _tree_t
{
	data_t	*data;
	long	num_elements,
			real_num_elements;
	int	levels,
			order,
			key_size;	
} tree_t;

/* this #include needs to be after the above definitions */
#include "misc.h"

/* adjust 'index' so it points to the 'index'th group of key_size */
#define INDEX(tree, index) \
	((index) * (tree)->key_size)

/* return address of data in 'tree' at 'index' */
#define DATA_AT(tree, index) \
	((tree)->data + INDEX(tree, index))

/*
 * LD_CMP() and LT_CMP() are pretty much the only macros defined below
 * that are used much.   TT_CMP() is also used for flushing in misc.c and
 * main.c
 *
 * DD == Data to Data
 * DT == Data to Tree
 * TT == Tree to Tree
 * LT == Long to Tree
 * etc. */
#define DD_COPY(a, b, size) \
	(strncpy(a, b, size))
#define DT_COPY(target, tree, i)	\
	(strncpy(target, DATA_AT(tree, i), (tree)->key_size))
#define TD_COPY(tree, i, src)	\
	(xstrncpy(DATA_AT(tree, i), src, (tree)->key_size))
#define TT_COPY(tree, targ_index, src_index)	\
	(strncpy( \
		DATA_AT(tree, targ_index), \
		DATA_AT(tree, src_index), \
		(tree)->key_size) \
	)

/* Greater Than */
#define DD_GT(a, b, size) \
	(xstrncmp(a, b, size) > 0)
#define DT_GT(b, tree, i) \
	((xstrncmp(b, DATA_AT(tree, i), (tree)->key_size)) > 0)
#define LT_GT(b, tree, i) \
	(xkeycharncmp(b, DATA_AT(tree, i), (tree)->key_size) > 0)
#define TD_GT(tree, i, b) \
	(xstrncmp(DATA_AT(tree, i), b, (tree)->key_size) > 0)
#define TT_GT(tree, i, j) \
	(xstrncmp(DATA_AT(tree, i), DATA_AT(tree, j), (tree)->key_size) > 0)

/* Less Than */
#define DD_LT(a, b, size) \
	(xstrncmp(a, b, size) < 0)
#define DT_LT(b, tree, i) \
	(xstrncmp(b, DATA_AT(tree, i), (tree)->key_size) < 0)
#define TD_LT(tree, i, b) \
	(xstrncmp(DATA_AT(tree, i), b, (tree)->key_size) < 0)
#define TT_LT(tree, i, j) \
	(xstrncmp(DATA_AT(tree, i), DATA_AT(tree, j), (tree)->key_size) < 0)

/* CoMPare, returns an integer <0, 0, or >0 */
#define DD_CMP(a, b, size) \
	(xstrncmp(a, b, size))
#define DT_CMP(b, tree, i)	\
	(xstrncmp(b, DATA_AT(tree, i), (tree)->key_size))
#define LD_CMP(lng, data, size) \
	(xkeycharncmp(lng, data, size))
#define LT_CMP(lng, tree, i) \
	LD_CMP(lng, DATA_AT(tree, i), (tree)->key_size)
#define TD_CMP(tree, i, b) \
	(xstrncmp(DATA_AT(tree, i), b, (tree)->key_size))
#define TT_CMP(tree, i, j) \
	xstrncmp(DATA_AT(tree, i), DATA_AT(tree, j), (tree)->key_size)

#define DT4_CMP(b, tree, i) \
	(xstrncmp((b), DATA_AT((tree), (i)), i))
#define xSTR4CMP(a, b) \
	(((a)[0] != (b)[0]) ?  \
		(a)[0] - (b)[0]  \
	:  \
		(((a)[1] != (b)[1]) ?  \
			(a)[1] - (b)[1]  \
		:  \
			(((a)[2] != (b)[2]) ?  \
				(a)[2] - (b)[2]  \
			:  \
				(((a)[3] != (b)[3]) ?  \
					(a)[3] - (b)[3]  \
				:  \
					0 \
				) \
			) \
		) \
	)

/* for arrays */
#define CMP(a, b, n) xstrncmp(a, b, n)
#define GT(a, b, n) (xstrncmp(a, b, n) > 0)
#define LT(a, b, n) (xstrncmp(a, b, n) < 0)


#endif

