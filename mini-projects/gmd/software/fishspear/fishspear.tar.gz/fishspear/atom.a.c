#include <sys/mman.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "atomdefs.h"


/* a cache line */
struct Tag 
{
	long tag;
	long valid;
} cache[CACHE_SIZE >> BLOCK_SHIFT];

/* the data structure for storing cache statistics */
struct Addr_range
{
	unsigned long	misses,
						hits,
						instructions;
} c_stats;
	
char	log_file_buf[BUFSIZE];
long	totalelems;
char	*nullstr = "(null)",
		*type,
		*nelems,
		*nops;
FILE	*log_fd = NULL;

/*********************************************************************/
void
reset_cache(void) 
{
	int index; 

	for (index = 0 ; index < (CACHE_SIZE >> BLOCK_SHIFT) ; index++) 
		cache[index].valid = 0;
}


#define NULLCHK(v, errmsg) if(! v){ fprintf(stderr, "%s", errmsg) ; exit(1); }

/* Instead of command line parameters, the atom code gets
 * parameters via environment variables.   Use these to 
 * initialize the analysis routines. */
void
initialize(void)
{
	char	*string,
			*file,
			*hostname;
	char	*order,
			*ksize;

	reset_cache();
	c_stats.misses = c_stats.instructions = c_stats.hits = 0;

	nelems = getenv("ATOM_NELEMS");
	NULLCHK(nelems, "nelems is NULL\n");
	nops = getenv("ATOM_NOPS");
	NULLCHK(nops, "nops is NULL\n");
	totalelems = atol(nelems);

	order = getenv("ATOM_ORDER");
	NULLCHK(order, "order is NULL\n");
	ksize = getenv("ATOM_KSIZE");
	NULLCHK(ksize, "ksize is NULL\n");

	type = getenv("ATOM_TYPE");
	NULLCHK(type, "type is NULL\n");

	file = getenv("ATOM_LOG_FILE");
	NULLCHK(file, "file is NULL\n");

	log_fd = fopen(file, "a");
	if(! log_fd)
	{
		fprintf(stderr, "Atom code can't open log file: '%s', ", file);
		perror(NULL);
		exit(1);
	}

	setbuffer(log_fd, log_file_buf, BUFSIZE);

}

void
finish(void)
{
	fprintf(log_fd, 
		"%s n %s S %s i %f m %f r %f\n", 
		type,
		nelems,
		nops,
		c_stats.instructions / (float) totalelems,
		c_stats.misses / (float) totalelems,
		(c_stats.misses + c_stats.hits) / (float) totalelems
	);

	fflush(stdout);
	fclose(log_fd);
}

void
reference(address)
	long	address;
{
	int	index;
	long	tag;

	index = (address & (CACHE_SIZE-1)) >> BLOCK_SHIFT;
	tag = address >> BLOCK_SHIFT;

	if(cache[index].valid == 0 || cache[index].tag != tag)
	{
		c_stats.misses++;
		cache[index].tag = tag;
		cache[index].valid = 1;
	} 
	else
	{
		c_stats.hits++;
	}
}

void
instruction(num)
	int	num;
{
	c_stats.instructions += num;
}


void
p(char *s)
{	printf("%s\n", s);
}