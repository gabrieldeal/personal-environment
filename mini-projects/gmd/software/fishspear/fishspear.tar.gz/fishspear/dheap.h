#ifndef HEAP_H
#define HEAP_H 1

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "common.h"

/*    hp_t.order is bad terminology, "order" means the number of 
 * keys per node here.
 */


typedef struct _hp_t
{
	data_t	*data,
				*tmpelem;
	long	top,		/* 1 + the highest existing index */
			capacity;
	int	order,	/* number of keys per node */
			ksize;	/* size of each key */
} hp_t;

void hp_print(hp_t*);

hp_t *hp_alloc(long, int, int);
void hp_dealloc(hp_t*);

int hp_insert(hp_t*, data_t const*);
int hp_delete(hp_t*, data_t*);
int hp_empty(hp_t*);

int _hp_pushdown(hp_t*, long);
int _hp_pushup(hp_t*, long);

#define _hp_error(hp, str) __hp_error(hp, str, __FILE__, __LINE__, stderr)
int __hp_error(hp_t*, char*, char*, int, FILE*);

/* let node range from (order - 1) .. (max_size + order - 2) */

/* Index of first Child */
/* To do:  optimize: node * ksize * order - order * order + order * 2 */
#define _HP_IC(hp, node) \
	(((node) - ((hp)->order - 2)) * (hp)->order)

/* Index of Parent */
#define _HP_IP(hp, node) \
	((node / (hp)->order) + (hp)->order - 2)

#define _HP_DATA_AT(hp, i) \
	((hp)->data + (i) * (hp)->ksize)

#define _HP_CMP(hp, i, j) \
	strncmp(_HP_DATA_AT(hp, i), _HP_DATA_AT(hp, j), (hp)->ksize)

/* Copying macros.  _HP_CP_HD() copies from a _H_eap to a _D_ata element,
 * _HP_CP_DH() copies from a data element to a heap.   _HP_CP_HH() copies
 * from a heap to that same heap. */
#define _HP_CP_HD(hp, i, elem) \
	strncpy(_HP_DATA_AT(hp, i), elem, (hp)->ksize)
#define _HP_CP_DH(hp, elem, i) \
	strncpy(elem, _HP_DATA_AT(hp, i), (hp)->ksize)
#define _HP_CP_HH(hp, i, j) \
	strncpy(_HP_DATA_AT(hp, i), _HP_DATA_AT(hp, j), (hp)->ksize)

#define _HP_SWAP(hp, n1, n2) \
{ \
	_HP_CP_DH(hp, (hp)->tmpelem, n1); \
	_HP_CP_HH(hp, n1, n2); \
	_HP_CP_HD(hp, n2, (hp)->tmpelem); \
}

#define HP_DEBUG FALSE

#endif
