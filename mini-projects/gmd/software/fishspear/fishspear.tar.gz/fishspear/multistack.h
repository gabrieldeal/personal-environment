/* this file uses width 3 tabs */

#ifndef MULTISTACK_H
#define MULTISTACK_H

#include "common.h"

/*    The multistack is laid out similiar to the heap and stack in memory,
 * U grows down and the V grows up. 
 *    Low order bits of elements in the stack are at the "top" of that
 * stack.   So the low order bits of the elements in the shaft have the
 * lower indice, and the low order bits in the barbs have higher indices.
 * 
 *       N
 * |---|
 * |   |            2
 * | S |            1
 * |   |            0 <- low order bit of elements in the shaft
 * |---|
 * |xxx|
 * |xxx|
 * |xxx|
 * |---|
 * |   |            0 <- low order bit of elements in a barb
 * | B |            1
 * |   |            2
 * |---|
 *      0
 */

/* Set this to FALSE to make the multistack functions return -1
 * on an error instead of just dying. */
extern int ms_die_flag;

/* The values are chosen to make operating on the stacks a bit easier.
 * if you want to shrink the S stack N units, just subtract MS_S * N
 * units from the stack and MS_S will automatically adjust for the fact
 * that the S stack shrinks up, similiar for addition and for the B 
 * stack. */
typedef enum _ms_side { MS_B = 1, MS_S = -1 } ms_side;

typedef struct _ms_t
{
	data_t	*data,
				*speek,	/* temporary memory, for use by ms_peek() */
				*bpeek;	/* temporary memory, for use by ms_peek() */

	/*    These arrays below are for convenience in the code, instead
	 * of testing which type it is and then using the appropriate
	 * variable, we can get the 'top' value for the 't' stack (where
	 * 't' is of type ms_side) from tops[t+1].   The values for the B
	 * stack are stored at index MS_B+1 in the arrays and similiar for
	 * the S stack, so the middle index is wasted. 
	 *   'tops' holds the highest in-use index for the stacks, and
	 * 'bottoms' holds the lowest in-use index.   when a stack is
	 * empty, there is no top-used index, so that value will be
	 * bottom-1. */
	long	tops[3],
			bottoms[3];

} ms_t;


ms_t *ms_alloc(long, long);
void ms_dealloc(ms_t *);

int ms_pop(ms_t *, ms_side, data_t *, long);
int ms_popmin(ms_t *, data_t *, long);
int ms_popmax(ms_t *, data_t *, long);
int ms_peek(ms_t *, ms_side, data_t *, long);
int ms_push(ms_t *, ms_side, const data_t *, long);

void ms_print(FILE*, ms_t*);

int _ms_error(char *, char *, int, ms_t *, FILE *);
#define ms_error(string, s) \
	_ms_error(string, __FILE__, __LINE__, s, stderr)

void _num2data(data_t*, long, long);
void _data2num(long*, data_t*, long);


#endif
