#ifndef COMMON_H
#define COMMON_H

#ifndef TRUE
	#define TRUE 1
#endif
#ifndef FALSE
	#define FALSE 0
#endif


typedef char data_t;


#endif
