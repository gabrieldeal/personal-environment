#include <stdio.h>
#include <strings.h>
#include "instrument.h"
#include "atomdefs.h"

int Instrument(void)
{
	Proc *proc;
	Block *block;
	Inst *inst;

	AddCallProto("initialize()");
	AddCallProto("finish()");
	AddCallProto("instruction(int)");
	AddCallProto("reference(VALUE)");

	AddCallProgram(ProgramBefore, "initialize");
	AddCallProgram(ProgramAfter, "finish");
	
	for(proc = GetFirstProc() ; proc != NULL ; proc = GetNextProc(proc)) 
	{
		for(block = GetFirstBlock(proc) ; block != NULL ; block = GetNextBlock(block)) 
		{
			AddCallBlock(block, BlockBefore, "instruction", GetBlockInfo(block, BlockNumberInsts));

			for(inst = GetFirstInst(block) ; inst != NULL ; inst = GetNextInst(inst)) 
			{
				if(IsInstType(inst, InstTypeLoad) || IsInstType(inst, InstTypeStore)) 
				{
					AddCallInst(inst, InstBefore, "reference", EffAddrValue);
				}
			}
		}
	}

	return 0;
}

