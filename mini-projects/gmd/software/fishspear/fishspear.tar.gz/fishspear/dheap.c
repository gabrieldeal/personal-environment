#include "dheap.h"

/* always pass the real index + 1. */


void
hp_print(hp)
	hp_t	*hp;
{
	long	i,
			j;

	printf("top %li, order %i, ksize %i\n", hp->top, hp->order, hp->ksize);
	for(i = hp->order - 1 ; i < hp->top ; i++)
	{
		for(j = 0 ; j < hp->ksize ; j++)
			printf("%c.", *(j + _HP_DATA_AT(hp, i)));
		printf(":");
	}
	printf("\n");
}


hp_t*
hp_alloc(nelems, ksize, order)
	long	nelems;
	int	ksize,
			order;
{
	hp_t	*hp;

	hp = malloc(sizeof(hp_t));
	if(hp == NULL)
	{
		_hp_error(NULL, "malloc() failed");
		return NULL;
	}

	hp->data = malloc(sizeof(data_t) * ksize * (nelems + order - 1));
	if(hp->data == NULL)
	{
		_hp_error(NULL, "malloc() failed");
		return NULL;
	}

	hp->tmpelem = malloc(sizeof(data_t) * ksize);
	if(hp->data == NULL)
	{
		_hp_error(NULL, "malloc() failed");
		return NULL;
	}

	hp->capacity = ksize * nelems;
	hp->top = order - 1;
	hp->order = order;
	hp->ksize = ksize;

	return hp;
}

void
hp_dealloc(hp)
	hp_t	*hp;
{
	if(hp != NULL)
	{
		if(hp->data != NULL)
			free(hp->data);
		if(hp->tmpelem != NULL)
			free(hp->tmpelem);

		free(hp);
	}
}

/* Invariant:  node >= hp->order - 1, node < hp->top. */
/* To do:  eliminate tail recursion. */
int
_hp_pushup(hp, node)
	hp_t	*hp;
	long	node;
{
	for(;;)
	{
		if(node == hp->order - 1)
			return 0;
	
		if(_HP_CMP(hp, _HP_IP(hp, node), node) > 0)
		{
			_HP_SWAP(hp, _HP_IP(hp, node), node);
			node = _HP_IP(hp, node);
		}
		else
			return 0;
	}

	/* not reached */
}

/* Invariant:  node >= hp->order - 1. */
int
_hp_pushdown(hp, node)
	hp_t	*hp;
	long	node;
{
	long	i,
			min,
			stop;

	for(;;)
	{
		if(node >= hp->top)
			return 0;
	
		i = _HP_IC(hp, node);
		stop = i + hp->order;
		/* To do: use sentinels and padding to get rid of this. */
		if(stop > hp->top)
			stop = hp->top;
	
		min = node;
		for( ; i < stop ; i++)
		{
			if(_HP_CMP(hp, i, min) < 0)
				min = i;
		}
		if(min != node)
		{
			_HP_SWAP(hp, min, node);
			node = min;
		}
		else
			return 0;
	}

	/* not reached */
}

int
hp_insert(hp, newelem)
	hp_t	*hp;
	data_t const	*newelem;
{
	if(HP_DEBUG) fprintf(stderr, "hp_insert start\n");
	_HP_CP_HD(hp, hp->top, newelem);
	hp->top++;
	_hp_pushup(hp, hp->top - 1);
	if(HP_DEBUG) fprintf(stderr, "hp_insert end\n");

	return 0;
}


int
hp_delete(hp, retelem)
	hp_t	*hp;
	data_t	*retelem;
{
	if(HP_DEBUG) fprintf(stderr, "hp_delete start\n");
	_HP_CP_DH(hp, retelem, hp->order - 1);
	hp->top--;
	_HP_CP_HH(hp, hp->order - 1, hp->top);
	_hp_pushdown(hp, hp->order - 1);
	if(HP_DEBUG) fprintf(stderr, "hp_delete end\n");

	return 0;
}

int
hp_empty(hp)
	hp_t	*hp;
{
	return hp->top == hp->order - 1;
}

int
__hp_error(hp, errmsg, file, line, stream)
	hp_t	*hp;
	char	*errmsg,
			*file;
	int	line;
	FILE	*stream;
{
	return -1;
}



