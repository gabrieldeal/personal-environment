/* this file uses width 3 tabs */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "multistack.h"


/* See multistack.h. */
int ms_die_flag = TRUE;

/* 
 * All of the following functions return < 0 on an error and 
 * >= 0 otherwise. 
 *
 */


void
ms_print(stream, s)
	FILE	*stream;
	ms_t	*s;
{
	fprintf(stream,
		"ms$ MS_S top %li, MS_S bottom %li, MS_B top %li, MS_B bottom %li.\n",
		s->tops[MS_S+1],
		s->bottoms[MS_S+1],
		s->tops[MS_B+1],
		s->bottoms[MS_B+1]
	);
}


/* Deallocate memory used by 's', assuming that 's' wasn't
 * statically allocated by the user. */
void
ms_dealloc(s)
	ms_t	*s;
{
	if(s)
	{
		if(s->data)
			free(s->data);
		if(s->speek)
			free(s->speek);
		if(s->bpeek)
			free(s->bpeek);
	
		free(s);
	}
}

/*    Return a pointer to a multistack structure with all its fields
 * initialized.
 *   'size' is the maximum number elements that will be needed in the
 * stack, 'ksize' is the largest element that will ever be added to 
 * the stack (used by ms_peek()). */
ms_t *
ms_alloc(size, ksize)
	long	size,
			ksize;
{
	ms_t	*s;

	if(!(s = malloc(sizeof(ms_t))))
	{
		ms_error("malloc() failed", NULL);
		return NULL;
	}

	if(!(s->data = malloc(sizeof(data_t)*size)))
	{
		ms_error("malloc() failed", NULL);
		return NULL;
	}
	if(!(s->speek = malloc(sizeof(data_t)*ksize)))
	{
		ms_error("malloc() failed", NULL);
		return NULL;
	}
	if(!(s->bpeek = malloc(sizeof(data_t)*ksize)))
	{
		ms_error("malloc() failed", NULL);
		return NULL;
	}

	s->bottoms[MS_S+1] = size - 1;
	s->tops[MS_S+1] = size;
	s->bottoms[MS_B+1] = 0;
	s->tops[MS_B+1] = -1;

	return s;
}

/* Remove the first 'size' elements on stack 'type', and copy them into
 * 'retelem'.   'retelem' must be at least 'size' long. */
int
ms_pop(s, type, retelem, size)
	ms_t	*s;
	ms_side	type;
	data_t	*retelem;
	long	size;
{
	long	index,
			i;

	index = s->tops[type+1];
	s->tops[type+1] -= type * size;
	if(type * (s->tops[type + 1] - s->bottoms[type + 1]) < -1)
		return ms_error("attempt to pop from empty stack", s);

	for(i = 0 ; i < size ; i++)
		retelem[i] = s->data[index - i * type];

	return 0;
}

/* Copy the top 'size' elements of stack 'type' into 'retelem'.
 * 'retelem' must be at least 'size' long. */
int
ms_peek(s, type, retelem, size)
	ms_t	*s;
	ms_side	type;
	data_t	*retelem;
	long	size;
{
	long	index,
			i;

	index = s->tops[type+1];
	if(type * (s->bottoms[type+1] - (index - size + 1)) > 0)
		return ms_error("peek on empty stack", s);

	for(i = 0 ; i < size ; i++)
		retelem[i] = s->data[index - i * type];

	return 0;
}

/* Pop the smallest of the two elements (one from the head of each
 * stack) from that stack and return it in 'retelem'. 
 * Returns MS_B+1 if it popped an element from stack B and MS_S+1 
 * otherwise. */
int
ms_popmin(s, retelem, size)
	ms_t	*s;
	data_t	*retelem;
	long	size;
{
	/* handle the cases where at least one of the stacks are empty */
	if(s->tops[MS_S+1] - MS_S * (size - 1) > s->bottoms[MS_S+1])
	{
		if(s->tops[MS_B+1] - MS_B * (size -1) < s->bottoms[MS_B+1])
			return ms_error("pop attempted on empty stacks", s);
		else
		{
			if(ms_pop(s, MS_B, retelem, size) < 0)
				return -1;
			return MS_B + 1;
		}
	}
	else if(s->tops[MS_B+1] - MS_B * (size -1) < s->bottoms[MS_B+1])
	{
		if(ms_pop(s, MS_S, retelem, size) < 0)
			return -1;
		return MS_S + 1;
	}

	/* handle the case where both stacks are non-empty */

	if(ms_peek(s, MS_B, s->bpeek, size) < 0)
		return -1;
	if(ms_peek(s, MS_S, s->speek, size) < 0)
		return -1;

	/* bias towards removing the barb to minimize the cost of the 
	 * barb merges */
	if(strncmp(s->bpeek, s->speek, size) > 0)
	{
		memcpy(retelem, s->speek, size);
		s->tops[MS_S+1] -= size*MS_S;
		return MS_S + 1;
	}
	else
	{
		memcpy(retelem, s->bpeek, size);
		s->tops[MS_B+1] -= size*MS_B;
		return MS_B + 1;
	}

	/* not reached */
}
int
ms_popmax(s, retelem, size)
	ms_t	*s;
	data_t	*retelem;
	long	size;
{
	if(s->tops[MS_S+1] - MS_S * (size - 1) > s->bottoms[MS_S+1])
	{
		if(s->tops[MS_B+1] - MS_B * (size -1) < s->bottoms[MS_B+1])
			return ms_error("pop attempted on empty stacks", s);
		else
		{
			if(ms_pop(s, MS_B, retelem, size) < 0)
				return -1;
			return MS_B + 1;
		}
	}
	else if(s->tops[MS_B+1] - MS_B * (size -1) < s->bottoms[MS_B+1])
	{
		if(ms_pop(s, MS_S, retelem, size) < 0)
			return -1;
		return MS_S + 1;
	}

	if(ms_peek(s, MS_B, s->bpeek, size) < 0)
		return -1;
	if(ms_peek(s, MS_S, s->speek, size) < 0)
		return -1;

	/* bias towards removing the barb to minimize the cost of the 
	 * barb merges */
	if(strncmp(s->speek, s->bpeek, size) < 0)
	{
		memcpy(retelem, s->bpeek, size);
		s->tops[MS_B+1] -= size*MS_B;
		return MS_B + 1;
	}
	else
	{
		memcpy(retelem, s->speek, size);
		s->tops[MS_S+1] -= size*MS_S;
		return MS_S + 1;
	}

	/* not reached */
}

/* Add the first 'size' elements of 'newelem' to stack 'type'. */
int
ms_push(s, type, newelem, size)
	ms_t	*s;
	ms_side	type;
	const data_t	*newelem;
	long	size;
{
	long	index,
			i;

	index = s->tops[type+1];
	s->tops[type+1] += type * size;
	if(s->tops[MS_S+1] - s->tops[MS_B+1] <= 0)
		return ms_error("attempted to fill stack past capacity", s);

	for(i = 0 ; i < size ; i++)
		s->data[index + (size - i)*type] = newelem[i];

	return 0;
}

/* Print out error messages and then either return -1 or exit() depending
 * on the value of ms_die_flag. */
int
_ms_error(string, file, line, s, out)
	char	*string,
			*file;
	int	line;
	ms_t	*s;
	FILE	*out;
{
	if(! out)
		out = stderr;

	fprintf(out, "Multistack error:  %s.\n", string);

	if(file)
		fprintf(out, "In file %s at line %i.\n", file, line);

	if(errno != 0)
		perror(NULL);

	if(s)
		ms_print(out, s);

	if(ms_die_flag)
		exit(1);
	else
		return -1;
}

/* Functions to convert between a long and an array of data_t. */
void
_num2data(data, num, size)
	data_t	*data;
	long	num,
			size;
{
	int	i;

	for(i = 0 ; i < size ; i++)
		data[i] = (0xff & (num >> (i*8)));
}
void
_data2num(num, data, size)
	long	*num;
	data_t	*data;
	long	size;
{
	int	i;

	*num = 0;
	for(i = 0 ; i < size ; i++)
		*num |= (data[i] & 0xff) << (i*8);
}
