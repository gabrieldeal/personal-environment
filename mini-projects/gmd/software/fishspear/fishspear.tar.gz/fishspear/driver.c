#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>

#include "dheap.h"
#include "fishspear.h"
#include "common.h"

#define TYPE(t) (t == 'h' ? "heap" : (t == 'f' ? "fishspear" : "mystery"))
#define DEBUG 0
#define PROGNAME	"driver"
#define ARGS "n:o:k:S:s:p:L:t:"
#define USAGE "\
Usage: %s -n NUM_ELEMENTS -S OPERATIONS [-o ORDER] [-k KEY_SIZE]\n\
          [-s SEED] [-L LOG_DIR] [-t type] [-p FILE]\n\n\
-n ..... no default.   Number of elements\n\
-S ..... no default.   Number of insert/delete operations\n\
-o ..... default is 8.   Order of the d-heap\n\
-k ..... default is 4.   size of the Keys to store\n\
-s ..... default is 0.   random Seed\n\
-L ..... default is /dev/null.   Log file to write to\n\
-t ..... default is 'h'.   Type of queue ('f' or 'h')\n\
-p ..... default is no logging.  file to write debug outPut to"

long	nelems,
		nops;	
int	order,
		ksize,
		seed,
		type;
FILE	*out_fh,
		*log_fh;
int	(*q_delete)(void *, char *);
int	(*q_insert)(void *, char *);
int	(*q_empty)(void *);
int	(*q_dealloc)(void *);

extern int ms_die_flag;

void parseopts(int, char**);
void getchardouble(char *);
void debug_output(char *);
struct timeval sub_time(struct timeval, struct timeval);
void output(struct timeval);


int
main(argc, argv)
	int	argc;
	char	**argv;
{
	void	*hp;
	long	i;
	char	data[sizeof(double)];
	struct timeval	bef, /* 1 microsecond = 1/1,000,000 seconds */
						aft, 
						adiff;

	ms_die_flag = FALSE;

	parseopts(argc, argv);
	if(ksize != sizeof(double))
	{
		fprintf(stderr, "Key size must be the same as sizeof(double).\n");
		exit(1);
	}
	if(type == 'h')
		hp = hp_alloc(nelems, ksize, order);
	else
		hp = fs_alloc(ksize, nelems);


	srand(seed);
	gettimeofday(&bef, NULL);
	printf("inserting...");
	fflush(stdout);
	for(i = 0 ; i < nelems ; i++)
	{
		getchardouble(data);
		q_insert(hp, data);
	}
	printf("\ninsert/deleting...");
	fflush(stdout);
	for(i = 0 ; i < nops ; i++)
	{
		q_delete(hp, data);
		if(out_fh)
			debug_output(data);
		getchardouble(data);
		q_insert(hp, data);
	}
	printf("\ndeleting...");
	fflush(stdout);
	while(! q_empty(hp))
	{
		q_delete(hp, data);
		if(out_fh)
			debug_output(data);
	}
	printf("\n");
	fflush(stdout);
	gettimeofday(&aft, NULL);
	adiff = sub_time(aft, bef);
	output(adiff);

	printf("%3li sec %7li usec (%li usec)\n", 
		(long) adiff.tv_sec, 
		(long) adiff.tv_usec,
		(long) adiff.tv_sec * 1000000 + adiff.tv_usec
	);

	q_dealloc(hp);
	if(out_fh)
		fclose(out_fh);

	return 0;
}

void
output(t)
	struct timeval t;
{

	if(log_fh)
	{
		fprintf(log_fh, 
			"%s %li %f\n", 
			TYPE(type), 
			nelems,
			((long)t.tv_sec*1000000+(long)t.tv_usec) / (float)nelems
		);
	}
}


struct timeval sub_time(struct timeval a, struct timeval b)
{
	struct timeval	ret_val;

	ret_val.tv_sec = a.tv_sec - b.tv_sec;
	ret_val.tv_usec = a.tv_usec - b.tv_usec;

	if(ret_val.tv_usec < 0)
	{
		ret_val.tv_sec--;
		ret_val.tv_usec += 1000000;
	}

	return ret_val;
}


void
debug_output(string)
	char	*string;
{
	int	i;

	if(! out_fh)
		return;

	for(i = 0 ; i < ksize ; i++)
		fprintf(out_fh, "%c", *(string + 1));
}

void
getchardouble(retelem)
	char	*retelem;
{
	double	d;

	d =  rand() / (double) RAND_MAX;
	strncpy(retelem, (char *) &d, sizeof(double));
}


void
parseopts(argc, argv)
	int	argc;
	char	**argv;
{
	int	error;
	char	arg;
	char	*file,
			*logfile = "/dev/null";

	error = 0;
	type = 'h';
	file = NULL;
	out_fh = NULL;
	seed = 0;
	ksize = 8;
	order = 4;
	while(! error && (arg = getopt(argc, argv, ARGS)) != -1)
	{
		switch(arg)
		{
			case 't':
				type = *optarg;
				break;
			case 'L':
				logfile = optarg;
				break;
			case 'p':
				file = optarg;
				break;
			case 's':
				seed = atoi(optarg);
				break;
			case 'n':
				nelems = atol(optarg);
				break;
			case 'o':
				order = atoi(optarg);
				break;
			case 'k':
				ksize = atoi(optarg);
				break;
			case 'S':
				nops = atol(optarg);
				break;

			default:
				error = 1;
				/* getopt() takes care of printing this error message */
				break;
		}
	}

	if(type != 'h' && type != 'f')
	{
		fprintf(stderr, "Bad type: '%c'\n", type);
		error = 1;
	}
	if(seed < 0)
	{
		fprintf(stderr, "Seed is less than zero: %i\n", seed);
		error = 1;
	}
	if(ksize <= 0)
	{
		fprintf(stderr, "Key size is too small: %i\n", ksize);
		error = 1;
	}
	if(nelems <= 0)
	{
		fprintf(stderr, "Number of elements is too small: %li\n", nelems);
		error = 1;
	}
	if(order <= 2)
	{
		fprintf(stderr, "Order is too small: %i\n", order);
		error = 1;
	}
	if(nops <= 0)
	{
		fprintf(stderr, "Number of operations is too small: %li\n", nops);
		error = 1;
	}
	if(file)
	{
		out_fh = fopen(file, "w");
		if(! out_fh)
		{
			fprintf(stderr, "Couldn't open '%s', ", file);
			perror(NULL);
			error = 1;
		}
	}

	if(error)
	{
		fprintf(stderr, "Usage: %s %s\n", PROGNAME, USAGE);
		exit(1);
	}

	switch(type)
	{
		case 'h':
			q_delete = hp_delete;
			q_insert = hp_insert;
			q_empty = hp_empty;
			q_dealloc = hp_dealloc;
			break;
		case 'f':
			q_delete = fs_delete;
			q_insert = fs_insert;
			q_empty = fs_empty;
			q_dealloc = fs_dealloc;
			break;
	}

	log_fh = fopen(logfile, "a");
	if(! log_fh)
	{
		fprintf(stderr, "Can't open log file: '%s', ", logfile);
		perror(NULL);
		exit(1);
	}
}
