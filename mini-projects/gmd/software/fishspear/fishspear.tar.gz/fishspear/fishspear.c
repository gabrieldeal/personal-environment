#include "fishspear.h"

int fs_die_flag = TRUE;

void
_fs_print(stream, fspr)
	FILE	*stream;
	fs_t	*fspr;
{
	fprintf(stream,
		"fs$ numsegments %li, "
		"data_ssize %li, "
		"data_bsize %li, "
		"u_ssize %li\n"
		"fs$ ksize %li, "
		"beta %0.2f, "
		"b %li, "
		"intsize %li.\n",
		fspr->numsegments,
		fspr->data_ssize,
		fspr->data_bsize,
		fspr->u_ssize,
		fspr->ksize,
		fspr->beta,
		fspr->b,
		fspr->intsize
	);
	ms_print(stream, fspr->datast);
}

void
fprintfn(stream, string, len)
	FILE	*stream;
	char	*string;
	int	len;
{
	int	tmp;

	for(tmp = 0 ; tmp < len ; tmp++)
		printf("%c", string[tmp]);
}


void
fs_insert(fspr, newelem)
	fs_t	*fspr;
	data_t const	*newelem;
{
	if(FS_DEBUG)
	{
		printf("fs_insert start\n");
		printf("Inserting:");
		fprintfn(stdout, newelem, fspr->ksize);
		printf(":\n");
	}

	barb_create(fspr, newelem);
	clean(fspr);

	if(FS_DEBUG) printf("fs_insert end\n");
}

void
fs_delete(fspr, retelem)
	fs_t	*fspr;
	data_t	*retelem;
{
	if(FS_DEBUG)
	{
		printf("fs_delete start\n");
		printf("Deleting\n");
	}

	delete_sharp(fspr, retelem);
	/* uncover W_k (U was on top) */
	if(fspr->data_ssize == 0)
	{
		if(fspr->numsegments > 0)
		{
			/* pop b */
			_fs_ms_pop(fspr->varbst, MS_B, fspr->tmpelem, B_SZ);
			_data2num(&(fspr->b), fspr->tmpelem, B_SZ);

			/* uncover W_k */
			_fs_ms_pop(fspr->datast, MS_S, fspr->tmpelem, fspr->intsize);
			_data2num(&(fspr->data_ssize), fspr->tmpelem, fspr->intsize);
		}
		else
			fspr->b = ceil(fspr->beta * fspr->u_ssize);

		clean(fspr);
	}

	if(FS_DEBUG) printf("fs_delete end\n");
}

int
fs_empty(fspr)
	fs_t	*fspr;
{
	if(FS_DEBUG) printf("fs_empty start\n");
	if(FS_DEBUG) printf("fs_empty end\n");

	return fspr->data_ssize == 0;
}

/* Invariant:  W_k non-empty */
/* U is reversed and in ust */
void
pmerge(fspr)
	fs_t	*fspr;
{
	int tmp;
	if(FS_DEBUG) printf("pmerge start\n");

	assert(fspr->data_ssize > 0);

	if(FS_DEBUG)
	{
		printf("PMERGE0: "); 
		ms_print(stdout, fspr->datast);
	}
	if(fspr->data_bsize == 0)
	{
		_fs_ms_pop(fspr->datast, MS_S, fspr->tmpelem, fspr->ksize);
		fspr->data_ssize--;
	}
	else
	{
		switch(ms_popmin(fspr->datast, fspr->tmpelem, fspr->ksize))
		{
			case MS_B+1:
				fspr->data_bsize--;
				break;
			case MS_S+1:
				fspr->data_ssize--;
				break;
			default:
				fs_error("ms_popmin() returned unexpected type", fspr);
				break;
		}
	}

	if(FS_DEBUG)
	{
		printf("pmerge got:");
		for(tmp = 0 ; tmp < fspr->ksize ; tmp++)
		printf("%c", fspr->tmpelem[tmp]);
		printf(":\n");
	}

	if(FS_DEBUG)
	{
		printf("PMERGE1: "); 
		ms_print(stdout, fspr->ust);
	}
	_fs_ms_push(fspr->ust, MS_S, fspr->tmpelem, fspr->ksize);
	fspr->u_ssize++;

	if(FS_DEBUG) printf("pmerge end\n");
}

/* Invariant: num_segments > 0, W_k is empty */
/* U is reversed and in ust */
void
barb_dispose(fspr)
	fs_t	*fspr;
{
	if(FS_DEBUG) printf("barb_dispose start\n");

	assert(fspr->numsegments > 0);
	assert(fspr->data_ssize == 0);

	if(fspr->numsegments == 1)
	{
		fspr->u_ssize += fspr->data_bsize;
		/* merge the remaining barb with U */
		while(fspr->data_bsize > 0)
		{
			_fs_ms_pop(fspr->datast, MS_B, fspr->tmpelem, fspr->ksize);
			_fs_ms_push(fspr->ust, MS_S, fspr->tmpelem, fspr->ksize);
			fspr->data_bsize--;
		}
	}
	else
	{
		/* merge the two barbs and uncover the next segment on the shaft */
		_barb_merge(fspr);
		_fs_ms_pop(fspr->datast, MS_S, fspr->tmpelem, fspr->intsize);
		_data2num(&(fspr->data_ssize), fspr->tmpelem, fspr->intsize);
	}

	fspr->numsegments--;

	if(fspr->numsegments > 0)
	{
		_fs_ms_pop(fspr->varbst, MS_B, fspr->tmpelem, B_SZ);
		_data2num(&(fspr->b), fspr->tmpelem, B_SZ);
	}
	else
		fspr->b = ceil(fspr->beta * fspr->u_ssize);


	if(FS_DEBUG) printf("barb_dispose end\n");
}

/* Invariant:  there are at least two segments in the B stack. */
/* U is reversed and in ust */
void
_barb_merge(fspr)
	fs_t	*fspr;
{
	long	total;
	ms_side	type;

	if(FS_DEBUG) printf("_barb_merge start\n");
	assert(fspr->numsegments >= 2);

	type = MS_B;
	total = 0;

	/* this loop is executed twice, once for each ms_side type. */
	MERGE_JUMP:
		total += fspr->data_bsize;
		/* empty the first barb */
		while(fspr->data_bsize > 0)
		{
			_fs_ms_pop(fspr->datast, MS_B, fspr->tmpelem, fspr->ksize);
			_fs_ms_push(fspr->mergest, type, fspr->tmpelem, fspr->ksize);
			fspr->data_bsize--;
		}
	/* pop the next segment or continue? */
	if(type == MS_B)
	{
		/* remove the size prepending the next segment */
		_fs_ms_pop(fspr->datast, MS_B, fspr->tmpelem, fspr->intsize);
		_data2num(&(fspr->data_bsize), fspr->tmpelem, fspr->intsize);

		type = MS_S;
		goto MERGE_JUMP;
	}

	fspr->data_bsize = total;
	/* merge the two barbs in mergest into datast MS_B */
	while(total > 0)
	{
		ms_popmax(fspr->mergest, fspr->tmpelem, fspr->ksize);
		_fs_ms_push(fspr->datast, MS_B, fspr->tmpelem, fspr->ksize);
		total--;
	}

	if(FS_DEBUG) printf("_barb_merge end\n");
}

fs_t *
fs_alloc(ksize, maxelem)
	long	ksize,
			maxelem;
{
	fs_t	*fspr;

	if(FS_DEBUG) printf("fs_alloc start\n");

	fspr = malloc(sizeof(fs_t));
	if(!fspr)
		fs_error("fs_alloc(), malloc failed", NULL);

	fspr->datast = ms_alloc(maxelem * MORE_SZ * ksize, ksize);
	if(!fspr->datast)
		fs_error("fs_alloc(), malloc failed", NULL);

	fspr->ust = ms_alloc(maxelem * ksize, ksize);
	if(!fspr->ust)
		fs_error("fs_alloc(), malloc failed", NULL);

	fspr->varbst = ms_alloc(maxelem * B_SZ, ksize);
	if(!fspr->varbst)
		fs_error("fs_alloc(), malloc failed", NULL);

	fspr->mergest = ms_alloc(maxelem  * ksize, ksize);
	if(!fspr->mergest)
		fs_error("fs_alloc(), malloc failed", NULL);

	fspr->tmpelem = malloc(sizeof(data_t)*ksize);
	if(!fspr->tmpelem)
		fs_error("fs_alloc(), malloc failed", NULL);

	fspr->numsegments = 0;
	fspr->data_ssize = 0;
	fspr->data_bsize = 0;
	fspr->u_ssize = 0;
	fspr->ksize = ksize;
	fspr->beta = 0.7034;
	fspr->b = 0;	/* == fspr->beta * fspr->u_ssize */
	fspr->intsize = SEG_NUM_SZ;

	if(FS_DEBUG) printf("fs_alloc end\n");
	return fspr;
}

void
fs_dealloc(fspr)
	fs_t	*fspr;
{
	if(fspr == NULL)
		return;

	if(FS_DEBUG) printf("fs_dealloc start\n");

	if(fspr->tmpelem != NULL)
		free(fspr->tmpelem);
	if(fspr->datast != NULL)
		ms_dealloc(fspr->datast);
	if(fspr->ust != NULL)
		ms_dealloc(fspr->ust);
	if(fspr->varbst != NULL)
		ms_dealloc(fspr->varbst);
	if(fspr->mergest != NULL)
		ms_dealloc(fspr->mergest);

	free(fspr);

	if(FS_DEBUG) printf("fs_dealloc end\n");
}

/* Invariant:  U is non-empty */
void
delete_sharp(fspr, retelem)
	fs_t	*fspr;
	data_t	*retelem;
{
	assert(fspr->data_ssize > 0);

	if(FS_DEBUG) printf("delete_sharp start\n");

	_fs_ms_pop(fspr->datast, MS_S, retelem, fspr->ksize);
	fspr->data_ssize--;

	if(FS_DEBUG) printf("delete_sharp end\n");
}

void
barb_create(fspr, newelem)
	fs_t	*fspr;
	data_t const	*newelem;
{
	if(FS_DEBUG) printf("barb_create start\n");

	/* close up barb at head */
	if(fspr->numsegments > 0)
	{
		if(FS_DEBUG) printf("Pushing %li onto barb stack\n", fspr->data_bsize);

		_num2data(fspr->tmpelem, fspr->data_bsize, fspr->intsize);
		_fs_ms_push(fspr->datast, MS_B, fspr->tmpelem, fspr->intsize);
	}
	

	/* start new barb */
	_fs_ms_push(fspr->datast, MS_B, newelem, fspr->ksize);
	fspr->data_bsize = 1;

	/* Now U is W_k and there is no U segment. 
	 * The next call after this one will be clean() which expects
	 * this, so it is just right */

	fspr->numsegments++;

	if(FS_DEBUG) printf("barb_create end\n");
}


/* Invariant:  U is empty */
void
clean(fspr)
	fs_t	*fspr;
{
	short	balanced;

	if(FS_DEBUG)
	{
		printf("clean start\n");
		_fs_print(stdout, fspr);
		ms_print(stdout, fspr->datast);
	}

	balanced = FALSE;
	while(fspr->numsegments > 0 && ! balanced)
	{
		if(fspr->data_ssize == 0)
		{
			if(FS_DEBUG) printf("BARB DISPOSE\n");
			barb_dispose(fspr);
			if(FS_DEBUG) _fs_print(stdout, fspr);
		}
		else if(fspr->data_bsize >= fspr->u_ssize || fspr->u_ssize >= fspr->b)
		{
			if(FS_DEBUG)
			{
				 printf("PMERGE %i %i\n", 
					fspr->data_bsize >= fspr->u_ssize, 
					fspr->u_ssize >= fspr->b
				);
			}
			pmerge(fspr);
		}
		else
		{
			balanced = TRUE;
			/* starting a new activation of S, save 'b' value */
			_num2data(fspr->tmpelem, fspr->b, fspr->intsize);
			_fs_ms_push(fspr->varbst, MS_B, fspr->tmpelem, B_SZ);
			fspr->b = ceil(fspr->beta * fspr->u_ssize);
		}
	}


	/* put U back on the shaft */
	if(fspr->numsegments > 0)
	{
		if(FS_DEBUG) printf("Pushing %li on segment stack\n", fspr->data_ssize);
		_num2data(fspr->tmpelem, fspr->data_ssize, fspr->intsize);
		_fs_ms_push(fspr->datast, MS_S, fspr->tmpelem, fspr->intsize);
	}
	fspr->data_ssize = fspr->u_ssize;
	while(fspr->u_ssize > 0)
	{
		_fs_ms_pop(fspr->ust, MS_S, fspr->tmpelem, fspr->ksize);
		if(FS_DEBUG)
		{
			printf("umergeback got:");
			fprintfn(stdout, fspr->tmpelem, fspr->ksize);
			printf(":\n");
		}
		_fs_ms_push(fspr->datast, MS_S, fspr->tmpelem, fspr->ksize);
		fspr->u_ssize--;
	}

	if(FS_DEBUG)
	{
		ms_print(stdout, fspr->datast);
		_fs_print(stdout, fspr);
		printf("clean end\n");
	}
}


/* Print out error messages and then either return -1 or exit() depending
 * on the value of fs_die_flag. */
int
_fs_error(string, file, line, fspr, out)
	char	*string,
			*file;
	int	line;
	fs_t	*fspr;
	FILE	*out;
{
	if(FS_DEBUG) printf("fs_error start\n");

	if(! out)
		out = stderr;

	fprintf(out, "Fishspear error:  %s.\n", string);

	if(file)
		fprintf(out, "In file %s at line %i.\n", file, line);

	if(errno != 0)
		perror(NULL);

	if(fspr)
		_fs_print(out, fspr);


	if(FS_DEBUG) printf("fs_error end\n");

	if(fs_die_flag)
		exit(1);
	else
		return -1;
}
