#ifndef FISHSPEAR_H
#define FISHSPEAR_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <errno.h>

#include <assert.h>

#include "common.h"
#include "multistack.h"

/* The Fishspear priority queue is presented in _Fishspear: A Priority
 * Queue Algorithm_ by Fischer and Patterson.   Journal of the ACM
 * Vol 41, No. 1 (Jan 1994) pp 3-30. */

/*	   The barbs are in the multistack's B section, and the shaft is in the
 *	S section.
 *	   Each segment in a stack is prepended by an 8-byte integer to indicate
 * how many elements this particular segment contains.   The exception
 *	to this is the top segments in both the shaft and the barbs, the
 *	sizes of these are kept in the fishspear structure.
 *	
 *	(Implement this?) The segment
 * ends with a sentinel element 0xffffffff (if 'ksize' == 8) so that 
 * merge() will always take an element from the other segment. 
 * (what happens if both elements
 * at the head of a segment are equal? perhaps i will simply not allow
 * 0xffffffff as a valid input element.)
 *	
 */

typedef struct _fs_t
{
	ms_t	*datast,			/* the actual queue */
			*ust,				/* holds U reversed while in clean() */
			*varbst,			/* holds the "b" values (variable b stack) use MS_B */
			*mergest;		/* for merging V_k and V_k-1 */
	data_t	*tmpelem;	/* used for holding segment sizes */

	double	beta;				/* magic balancer, used by clean() */

	long	numsegments,	/* total number of segments in the fishspear */
			data_ssize,		/* number of elements in top segment in the shaft */
			data_bsize,		/* number of elements in top segment of the barbs */
			u_ssize,			/* number of elements in shaft of 'ust' */
			ksize,			/* bytes per element in the fishspear (key size) */
			b,					/* magic balancer, used by clean() */
			intsize;			/* size of the integers prepending each segment */
} fs_t;

/* These are the only "public" functions. */

int fs_empty(fs_t*);
void fs_insert(fs_t*, data_t const*);
void fs_delete(fs_t*, data_t*);
fs_t *fs_alloc(long, long);
void fs_dealloc(fs_t*);


/* Private. */

/* the functions described by Fischer/Patterson */
void clean(fs_t*);
void delete_sharp(fs_t*, data_t*);
void barb_create(fs_t*, data_t const*);
void pmerge(fs_t*);
void barb_dispose(fs_t*);

void _barb_merge(fs_t*);
void _fs_print(FILE*, fs_t*);

int _fs_error(char*, char*, int, fs_t*, FILE*);
#define fs_error(string, fspr) \
	_fs_error(string, __FILE__, __LINE__, fspr, stderr)

#define _fs_ms_pop(s, t, e, sz) \
	{if(ms_pop(s, t, e, sz) < 0) fs_error("fishspear ms_pop() error", fspr);}

#define _fs_ms_push(s, t, e, sz) \
	{if(ms_push(s, t, e, sz) < 0) fs_error("fishspear ms_push() error", fspr);}

/* How much more stack space to allocate than size of elements in the stack. */
#define MORE_SZ (5.0/3.0)

/* For usegment. */
#define LESS_SZ (1.0/3.0)

/* oops, what's the difference? */
/**/
/* How many bytes in the size indicator for segments. */
#define SEG_NUM_SZ 4

#define B_SZ sizeof(long)

#ifndef FS_DEBUG
	#define FS_DEBUG FALSE
#endif


#endif

