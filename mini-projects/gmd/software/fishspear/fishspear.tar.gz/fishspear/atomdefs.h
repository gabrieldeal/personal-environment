#ifndef ADEFS_DOT_H
#define ADEFS_DOT_H

#include <string.h>

/* REMEMBER to change NUM_SLOTS in cache.a.c if you define REF_MAP or
 * DUMP */ 



/* To use the map (locations of references or misses) define MAP
 * and one of REF_MAP or MISS_MAP.   REF_MAP will give a map of
 * all the references to data registered by the instrumented
 * program, MISS_MAP will give a map of all the cache misses */
#undef MAP

#undef REF_MAP
#undef MISS_MAP

/* The maximum number of memory locations we can keep cache reference
 * counts on.   Beware, making this too large can cause the following 
 * error:
 *   20280:./btree.atom: /sbin/loader: Fatal Error: noncontiguous 
 *   data and bss is not supported
 */
#define REF_NUM_MAX 1000000


/* used to write copious output about each search.   Very time
 * consuming and uses loads of disk space. */
#define DUMP 1


#define DEBUG 0

/* I got the heart of the cache reference simulation code
 * (namely reference()) from Jim Fix. */

/* 4 different areas to store cache stats in.
 * For instance perhaps Trad binary search stats are kept in area 0 and
 * CCSS in 1.  */
#define NUM_SLOTS 4

/* Different address ranges I wish to keep seperate.   For instance
 * the flush array and the array with the search data.  See the warning
 * in the REF_NUM_MAX comments -- it applies here too. */
#define NUM_RANGES 2

/* buffer size for buffers used instead of the normal buffers used by the
 * I/O functions */
#define BUFSIZE 65536		

/* Configure the size of the cache and the size of cache lines. */
#define CACHE_SIZE 2097152 /* in bytes, 2^20 = 1048576, 2^21 = 2097152 */
#define BLOCK_SHIFT 5		/* block size is 2^BLOCK_SHIFT == 32 */

#define SLOT_CHECK(s) \
	if(s >= NUM_SLOTS || s < 0) \
	{ \
		fprintf(stderr, \
			"File %s line %i error: bad slot number: %i.\n", \
			__FILE__, \
			__LINE__, \
			s \
		); \
		exit(1); \
	}

#define NULL_FIX(a) if(a == NULL) a = nullstr;


#endif


