#ifndef UTILS_H
#define UTILS_H 1


#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>


void *xmalloc(size_t n, char *, int);
char get_random_char();
char *get_random_string(int, int);
int get_rand_int(int);
struct timeval sub_time(struct timeval a, struct timeval b);

#endif


