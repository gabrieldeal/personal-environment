package Rball;

# Copyright (c) 1999 Gabriel Deal. All rights reserved.
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.


my $debug = undef;
#my $debug = STDERR;

use strict;
use AsciiDB::TagFile;
use Misc;
use Globals;

sub new
{
	Misc::debug_start($debug) if defined $debug and $debug;
	my $class = shift;
	@_ <= 1 or Misc::bad_args("1 or 0", scalar @_);
	my $mode = shift;

	if(defined $mode and $mode =~ /^r$/i)
	{
		$mode = 1;
	}
	else
	{
		$mode = 0;
	}	

	my $dir = $Global::this_dir;

	my $self = {};
	$class = ref $class || $class;
	bless $self, $class;

	{
		my($A, $B, %h);
		my $fun = sub { 
				($A) = ($h{$a} =~ /^(\d+)\s*/);
				($B) = ($h{$b} =~ /^(\d+)\s*/);
				$A <=> $B
		};

		%h = %{Globals::user_cols};
 		$self->{'g_user_cols'} = [ sort { &$fun() } keys(%h) ];
		%h = %Globals::description_cols;
 		$self->{'g_description_cols'} = [ sort { &$fun } keys %Globals::description_cols ];
	}


	
 	$self->{'g_user_map'} = { eval { my $i = 1; return map { $_ => $i++ } @{ $self->{'g_user_cols'} } } };
	$self->{'g_user_map'}{email} = 0;
 	$self->{'g_description_map'} = { eval { my $i = 1; return map { $_ => $i++ } @{ $self->{'g_description_cols'} } } };
	$self->{'g_description_map'}{'time'} = 0;

	$self->{'g_user_db_name'} = $Globals::user_db_name;
	$self->{'g_description_db_name'} = $Globals::description_db_name;
	$self->{'g_save_db_name'} = $Globals::save_db_name;

	$self->{'g_num_ladders'} = $Globals::num_ladders;
	$self->{'g_maintainer_email'} = $Globals::maintainer_email;
	$self->{'g_db_dir'} = $Globals::db_dir;
	$self->{'g_sufix'} = $Globals::suffix;

	$self->{'g_error'} = $Globals::error;

	$self->{'g_obj_users'} = tie %{ $self->{'g_hash_users'} }, 'AsciiDB::TagFile',
		DIRECTORY => "$self->{'g_db_dir'}/$self->{'g_user_db_name'}",
		SUFIX => $self->{'g_sufix'},
		READONLY => $mode,
		FILEMODE => 0600,
		SCHEMA => {
			ORDER => [ @{ $self->{'g_user_cols'} } ]
		};

	$self->{'g_obj_description'} = tie %{ $self->{'g_hash_description'} }, 'AsciiDB::TagFile',
		DIRECTORY => "$self->{'g_db_dir'}/$self->{'g_description_db_name'}",
		SUFIX => $self->{'g_sufix'},
		READONLY => $mode,
		FILEMODE => 0600,
		SCHEMA => {
			ORDER => [ @{ $self->{'g_description_cols'} } ]
		};

	$self->{'g_obj_save'} = tie %{ $self->{'g_hash_save'} }, 'AsciiDB::TagFile',
		DIRECTORY => "$self->{'g_db_dir'}/$self->{'g_save_db_name'}",
		SUFIX => $self->{'g_sufix'},
		READONLY => $mode,
		FILEMODE => 0600,
		SCHEMA => {
			ORDER => [ @{ $self->{'g_user_cols'} } ]
		};

	$self->make_ladders();

	Misc::debug_end($debug) if defined $debug and $debug;
	return $self;
}


# used by court_report.cgi.
# silly idea and shouldn't be used.
sub description_map
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ == 1 or Misc::bad_args(1, scalar @_);
	my $field = shift;

	my $return = $self->{'g_description_map'}{$field};

	Misc::debug_start($debug, $return) if defined $debug and $debug;
	return $return;
}

sub user_delete
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ == 1 or Misc::bad_args(1, scalar @_);
	my $email = shift;

	die "No such user: $email." unless exists $self->{g_hash_users}{$email};

	my $ladder = $self->{g_hash_users}{$email}{ladder};

	foreach(@{ $self->{g_user_cols} })
	{
		$self->{g_hash_save}{$email}{$_} = $self->{g_hash_users}{$email}{$_};
	}

	$self->create_description(time, 
		event => "$email left the ladder."
	);

	delete $self->{g_hash_users}{$email};
	$self->make_ladders(1);

	Misc::debug_start($debug) if defined $debug and $debug;
}

sub user_map
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ == 1 or Misc::bad_args(1, scalar @_);
	my $field = shift;

	my $return = $self->{'g_user_map'}{$field};

	Misc::debug_start($debug, $return) if defined $debug and $debug;
	return $return;
}


=head1 make_ladders([$flag]) : void

This method reads the ladders into the 2-D array $self->{g_ladders}.
It also corrects any gaps in the rankings.   If flag is passed and is
true, then make_ladders() will expect gaps to exist and won't email
the maintainer, otherwise the maintainer is informed of this error.

=cut
sub make_ladders
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ <= 1 or Misc::bad_args("0 or 1", scalar @_);
	my $flag = shift;

	$flag = 0 if ! defined $flag;

	my @array;

	# just in case there's nobody on one of the ladders, must create
	# the array reference so later code won't break when it refers
	# to it as an array.
	foreach(1 .. $self->{g_num_ladders})
	{
		$array[$_] = [];
		$self->{g_ladders}[$_] = [];
	}

	# group users by ladder
	my($ladder, $rank, $user, $cnt);
	foreach $user (keys %{ $self->{g_hash_users} })
	{
		$ladder = $self->{g_hash_users}{$user}{ladder};
		push @{ $array[$ladder] }, $user;
	}

	foreach $ladder (1 .. $self->{g_num_ladders})
	{
		@{ $array[$ladder] } = sort { 
				$self->{g_hash_users}{$a}{rank} <=> $self->{g_hash_users}{$b}{rank} 
			} @{ $array[$ladder] };
		$cnt = 1;
		foreach $user (@{ $array[$ladder] })
		{
			if(! $flag and $self->{g_hash_users}{$user}{rank} != $cnt)
			{
				system(qq!echo "$user should be $cnt on ladder $ladder but is ranked $self->{g_hash_users}{$user}{rank} in the DB. (flag == $flag)" | /bin/mailx -s 'UWIRL rankings' $Globals::maintainer_email!);
				warn "$self->{g_error} inconsistency detected in the rankings.<P>";
			}

			# might as well, just in case...
			$self->{g_hash_users}{$user}{rank} = $cnt;
			$self->{g_ladders}[$ladder][$cnt] = $user;

			$cnt++;
		}
	}

# 		$self->{g_ladders}[$ladder][$rank] = $user;

	Misc::debug_end($debug) if defined $debug and $debug;
}

sub rank_difference
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ == 2 or Misc::bad_args(2, scalar @_);
	my $user_a = shift;
	my $user_b = shift;

	my $ladder_a = ${ $self->{'g_hash_users'} }{$user_a}{'ladder'};
	my $ladder_b = ${ $self->{'g_hash_users'} }{$user_b}{'ladder'};

	my $rank_a = ${ $self->{g_hash_users} }{$user_a}{'rank'};
	my $rank_b = ${ $self->{g_hash_users} }{$user_b}{'rank'};

	if($ladder_a == $ladder_b)
	{
		return $rank_b - $rank_a;
	}

	my $members_hi;
	my($hi, $lo, $rank_hi, $rank_lo);
	if($ladder_a > $ladder_b)
	{
		$members_hi = $self->max($ladder_b);
		$hi = $ladder_b;
		$lo = $ladder_a;
		$rank_hi = $rank_b;
		$rank_lo = $rank_a;
	}
	else
	{
		$members_hi = $self->max($ladder_a);
		$hi = $ladder_a;
		$lo = $ladder_b;
		$rank_hi = $rank_a;
		$rank_lo = $rank_b;
	}

	my $num = ($members_hi - $rank_hi) + $rank_lo;
	if($hi - $lo == 1)
	{
		return ($ladder_a < $ladder_b) ? $num : -$num;
	}

	my(%h, $o);
	foreach my $i ($hi + 1 .. $lo - 1)
	{
		$num += $self->max($i);
	}

	return ($ladder_a < $ladder_b) ? $num : -$num;
	Misc::debug_end($debug) if defined $debug and $debug;
}




=head1 get_email() : @emails

Return array with email addresses of all people in the user database.

=cut
sub get_email
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ == 0 or Misc::bad_args(0, scalar @_);

	return keys %{ $self->{'g_hash_users'} };

	Misc::debug_start($debug, @_) if defined $debug and $debug;
}

=head get_info($email) : @db_columns

Return all the columns in the database associated with $email.

=cut
sub get_info
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ == 1 or Misc::bad_args(1, scalar @_);
	my $email = shift;

	my %info = ();
	return %info if ! exists ${ $self->{'g_hash_users'} }{$email};

	foreach(@{ $self->{'g_user_cols'} })
	{
		next if ! exists ${ $self->{'g_hash_users'} }{$email}{$_};
		$info{$_} = ${ $self->{'g_hash_users'} }{$email}{$_};
	}

	Misc::debug_end($debug) if defined $debug and $debug;

	return %info;
}


########################


sub create_description
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ >= 0 or Misc::bad_args("0+", scalar @_);
	my $time = shift;
	my %h = @_;

	$self->check_description($time, %h);
	$self->update_description($time, %h);

	Misc::debug_end($debug, @_) if defined $debug and $debug;
}

sub check_description
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ >= 2 or Misc::bad_args("2+", scalar @_);
	my $time = shift;
	my %h = @_;

	my $errors = "";
	$errors .= "Bad time format: $time.\n" if defined $time and $time !~ /^\d+$/;
	$errors .= "Time not specified.\n" if ! defined $time;

	my $var;
	foreach(keys %h)
	{
		/^(.)(.*)/;
		$var = uc($1) . $2;
		# this is rather broken...
		if(/loser/ or /winner/)
		{
			$errors .= "$var address not specified.\n" if $h{$_} =~ /^\s*$/;
		}
		elsif(/create-info/ or /modify-info/)
		{
			$errors .= "Bad format for $_: $h{$_}.\n" if $h{$_} !~ /^\S+:\d+$/;
		}
	}
	die "$self->{'g_error'}$errors " if $errors ne "";

	Misc::debug_end($debug) if defined $debug and $debug;
}

sub update_description
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ >= 1 or Misc::bad_args("1+", scalar @_);
	my $email = shift;
	my %h = @_;

	delete $h{'create-info'} if exists $h{'create-info'} and exists ${ $self->{'g_hash_description'} }{'create-info'};
	$h{'modify-info'} = "X:" . time;
	foreach(keys %h)
	{
		${ $self->{'g_hash_description'} }{$email}{$_} = $h{$_};
	}

	Misc::debug_end($debug) if defined $debug and $debug;
}


sub get_description_order
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ == 0 or Misc::bad_args(0, scalar @_);

	my @return = ('time', @{ $self->{'g_description_cols'} });

	Misc::debug_start($debug, @return) if defined $debug and $debug;
	return @return;
}
sub get_description
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ == 0 or Misc::bad_args(0, scalar @_);

	my(@line, @return, $email);
	foreach my $time (sort { $b <=> $a } keys %{ $self->{'g_hash_description'} })
	{
		@line = ();
		push @line, $time;
		foreach my $key (@{ $self->{'g_description_cols'} })
		{
			push @line, ${ $self->{"g_hash_description"} }{$time}{$key};
		}
		push @return, [ @line ];
	}	


	Misc::debug_end($debug) if defined $debug and $debug;
	return @return;
}



#############3


# no longer used
# 
# sub repair_ranks
# {
# 	Misc::debug_start($debug, @_) if defined $debug and $debug;
# 	my $self = shift;
# 	@_ == 1 or Misc::bad_args(1, scalar @_);
# 	my $ladder = shift;
# 
# 	foreach(1 .. $self->max($ladder))
# 	{
# 		$self->update_user($self->{g_ladders}[$ladder][$_],
# 			'rank' => $_
# 		);
# 	}
# 
# 	Misc::debug_end($debug) if defined $debug and $debug;
# }

sub get_user_order
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ == 0 or Misc::bad_args(0, scalar @_);

	my @return = ('email', @{ $self->{'g_user_cols'} });

	Misc::debug_end($debug, @return) if defined $debug and $debug;
	return @return;
}
sub get_ladder
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ == 1 or Misc::bad_args(1, scalar @_);
	my $l_num = shift;

	my(@line, @return, %hash, $email);

	foreach(1 .. $#{ $self->{g_ladders}[$l_num] })
	{
		%hash = ();
		$hash{email} = $email = $self->{g_ladders}[$l_num][$_];
		foreach my $key (@{ $self->{'g_user_cols'} })
		{
			$hash{$key} = $self->{'g_hash_users'}{$email}{$key};
		}
		push @return, { %hash };
	}	


# 	$ladder_obj->purge();
# 	$user_obj->purge();

	Misc::debug_end($debug) if defined $debug and $debug;
	return @return;
}


################

# error checking should already be done before this function is called
sub update_user
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ >= 1 or Misc::bad_args("1+", scalar @_);
	my $email = shift;
	my %h = @_;

	delete $h{'create-info'} if exists $h{'create-info'} and exists $self->{'g_hash_user'}{$email}{'create-info'};
	$h{'modify-info'} = "X:" . time;
	foreach(keys %h)
	{
		${ $self->{g_hash_users} }{$email}{$_} = $h{$_};
	}

	$self->{'g_obj_users'}->sync();
	$self->{'g_obj_users'}->purge();

	Misc::debug_end($debug) if defined $debug and $debug;
}

sub modify_user
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ >= 2 or Misc::bad_args("2+", scalar @_);
	my $old_email = shift;
	my $email = shift;
	my %h = @_;

	$self->check_user($email, %h);

	my $errors = "";
	$errors .= "Original email address not specified.\n" if $old_email =~ /^\s*$/;
	$errors .= "No such email address: $old_email.\n" if ! exists ${ $self->{'g_hash_users'} }{$old_email};
	Misc::xdie "$self->{'g_error'}$errors " if $errors ne "";

	# save old values in case we're changing the email
	# address and have to delete the row.
	foreach(@{ $self->{'g_user_cols'} })
	{
		next if exists $h{$_};
		$h{$_} = ${ $self->{"g_hash_users"} }{$old_email}{$_};
	}

	delete ${ $self->{'g_hash_users'} }{$old_email} if $old_email ne $email;
	$self->update_user($email, %h);

	Misc::debug_end($debug) if defined $debug and $debug;
}

sub check_required
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ >= 1 or Misc::bad_args("1+", scalar @_);
	my $email = shift;
	my %h = @_;

	Misc::xdie "$_ not specified.\n" if ! $email =~ /^\s*$/;

	my $errors = "";
	foreach(@{ $self->{'g_user_required_cols'} })
	{
		/^(\S)(.*)$/;
		$errors .= uc($1) . "$2 not specified.\n" if ! exists $h{$email};
	}
	Misc::xdie "$errors " if $errors ne "";

	Misc::debug_start($debug) if defined $debug and $debug;
}

sub check_user
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ >= 1 or Misc::bad_args("1+", scalar @_);
	my $email = shift;
	my %h = @_;

	my $errors = "";
	#$errors .= "Email address not specified.\n" if $email =~ /^\s*$/;
	#$errors .= "Status not specified.\n" if ! defined $h{'status'};

	foreach(keys %h)
	{
		if(/passwd/)
		{
			#$errors .= "Password not specified.\n" if $h{$_} =~ /^\s*$/;
		}
		elsif(/ladder/)
		{
			#($errors .= "Ladder not specified.\n"), next if $h{$_} =~ /^\s*$/;
			($errors .= "Ladder not a number: $h{$_}.\n"), next if $h{$_} !~ /^\d+$/;
			($errors .= "Ladder out of range: $h{$_}.\n"), next if $h{$_} < 1 or $h{$_} > $self->{'g_num_ladders'};
		}
		elsif(/status/)
		{
			# ignore
		}
		elsif(/wins/ or /losses/ or /forfeit/)
		{
			$errors .= "$_ not a number: $h{$_}.\n" if $h{$_} !~ /^\d+$/;
		}
		elsif(/create-info/ or /modify-info/)
		{
			$errors .= "Bad format for $_: $h{$_}.\n" if $h{$_} !~ /^\S+:\d+$/;
		}
	}

	die "$self->{'g_error'}$errors " if $errors ne "";

	Misc::debug_end($debug) if defined $debug and $debug;
}

sub create_user
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ >= 1 or Misc::bad_args("1+", scalar @_);
	my $email = shift;
	my %h = @_;

	$h{'forfeit'} = 0 if ! exists $h{'forfeit'};
	$self->check_user($email, %h);
	my $errors = "";
	$errors .= "Email address ($email) is already in use.  (You didn't reload this page, did you?)\n" if exists ${ $self->{'g_hash_users'} }{$email};
	die "$self->{'g_error'}$errors " if $errors ne "";
	
	$self->update_user($email, %h);

# 	$user_obj->sync();
# 	$user_obj->purge();

	Misc::debug_end($debug) if defined $debug and $debug;
}


sub max
{
	Misc::debug_start($debug, @_) if defined $debug and $debug;
	my $self = shift;
	@_ >= 1 or Misc::bad_args(1, scalar @_);
	my $ladder = shift;

	my $max = scalar @{ $self->{g_ladders}[$ladder] };

	# because the array starts at 1.   so when the first array
	# spot is assigned to spot 1, spot 0 is created automatically.
	$max-- if $max > 0;

	foreach(1 .. $max)
	{
		$max-- if ! defined $self->{g_ladders}[$ladder][$_];
	}

	Misc::debug_end($debug, $max) if defined $debug and $debug;
	return $max;
}


1;
