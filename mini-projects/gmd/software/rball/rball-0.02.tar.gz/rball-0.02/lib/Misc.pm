package Misc;

# Copyright (c) 1999 Gabriel Deal. All rights reserved.
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.


require Exporter;
@ISA = qw(Exporter);
@EXPORT_OK = qw(&debug_start &debug_end &bad_args &try &catch &error);

#my $debug = *STDERR{IO};

use Carp;

=head1 Various functions I often find useful

=cut

=head2 	sub debug_start($;@)

Prints out useful diagnostic information when entering a function.
The first argument is the filehandle to print to, the second is the
arguments to the function it is called from.

Try calling it like this from class methods:
  Misc::debug_start($debug_fh, @_[ 1 .. $#_ ]) if defined $debug and $debug;

=cut

=head2 	sub debug_end($;$)

Prints out useful diagnostic information right before exiting a
function.   Assumes that the function will exit on the next line.
Pass it the filehandle to print to, and the return value of the
function.

=cut

{	# a closure, $count is static and shared between the two functions

	my $count = 0;
	sub debug_start($;@)
	{	my $fh = shift || *STDERR{IO};
		my @arguments = @_;

		my $save = $^W;	# setting $^W to false unsets the '-w' flag
		$^W = 0;
		@arguments = map { chomp $_ ; s/^\s+// ; s/\s+$// ; s/\s+/ /g ; $_ } @arguments;
		$^W = $save;
		my ($package, $filename, $line, $subroutine,
			$hasargs, $wantarray, $evaltext, $is_require) = caller(1);

		$count++;
		print $fh "$subroutine(";
		$^W = 0;
		print $fh join(", ", @arguments);
		$^W = $save;
		print $fh "): entering (called at line $line of $filename, level #$count)\n";
	}
	sub debug_end($;$)
	{	my $fh = shift || *STDERR{IO};
		my @ret_val = @_;

		print $fh +(caller 1)[3] 
			. "(): leaving at line "
			. ((caller 0)[2] + 1)	# assume next line is 'return ...'
			. " (level #$count)"
			. (@ret_val > 0 ? ", returning: '" . join(' ', @ret_val) . "'.\n" : ".\n");
		$count--;
	}
}

=head2	stack_trace()

Return an array containing filename, function, and line information
about each function currently on the stack.

=cut

sub stack_trace
{	debug_start($debug) if defined $debug and $debug;

	my $i = 0;
	my($filename, $line, $subroutine, @stack_trace);
	while(($filename, $line, $subroutine) = (caller $i)[1, 2, 3])
	{
		$i++;
		unshift @stack_trace, "$filename $subroutine() line $line";
	}

	debug_end($debug) if defined $debug and $debug;
	return @stack_trace;
}

=head2 xdie(;@)

Exit by passing the elements of the passed array to die(), if the last
element in the passed array does not end with a newline (or no
arguments are passed), also print out a stack trace after printing the
other passed arguments.

=cut

sub xdie
{	debug_start($debug) if defined $debug and $debug;

	if(@_ == 0 or $_[$#_] !~ /\n$/)
	{
		my @stack_trace = Misc::stack_trace();
		pop @stack_trace;
		die join(' ', @_)
			. "\nStack Trace:\n\t"
			. join("\n\t", @stack_trace)
			. "\n";
	}
	else
	{
		die join(' ', @_);
	}

	debug_end($debug) if defined $debug and $debug;
}

=head2	bad_args($$)

I often use this to at the start of my functions like this:

 @_ == 1 or @_ == 2 Misc::bad_args("1 or 2", scalar @_);

to perform a small sanity check on the number of arguments passed.

=cut

sub bad_args($$) # ($args_expected, $args_given)
{	debug_start($debug) if defined $debug and $debug;
	my($args_expected, $args_given) = @_;

	my @stack_trace = &stack_trace();
	my($filename, $line, $subroutine) = (caller 0)[1, 2, 3];
	($subroutine) = (caller 1)[3];

	xdie "Bad arguments to $subroutine at line $line in $filename.\n"
		. "$args_given arguments given when $args_expected arguments expected.\n"
		. "Stack trace:\n\t"
		. join("\n\t", @stack_trace[0 .. ($#stack_trace - 1)])
		. "\n";

	debug_end($debug) if defined $debug and $debug;
}	

=head2 error(%)

Print out useful error message.   Kind of dumb right now, I wanted to
be able to pass it a message and/or a filehandle to print to.   One
problem is we don't want to use 'exit' if we're called from within an
'eval', so i need to check the whole call stack to see if we are
within the scope of an 'eval'.   Haven't done this yet, so the
filehandle argument is simply not used, instead we die whether or not
we're within an eval.   the $^W doesn't work either.. ack.

=cut

sub error(%)
{	debug_start($debug, scalar @_) if defined $debug and $debug;

	my($msg, $fh, %hash);
	my $save = $^W;
	$^W = 0;
	%hash = @_;
	$^W = $save;
	if(@_ == 2 and (defined $hash{'err_message'} ^ defined $hash{'out_fh'})
		or
		@_ == 4 and (defined $hash{'err_message'} and defined $hash{'out_fh'})
	  )
	{	$fh = $hash{'out_fh'} if defined $hash{'out_fh'};
		$msg = $hash{'err_message'} if defined $hash{'err_message'};
	} else
	{	$msg = shift;
		$fh = shift if @_ > 0;
	}

	$fh = *STDERR{IO} unless defined $fh;
	$msg = defined $msg ? qq!:\n\t"$msg".\n! : ".\n";

	my($package, $filename, $line) = (caller 0)[0, 1, 2];
	my($subroutine) = (caller 1)[3];
	$subroutine = defined $subroutine ? "$subroutine()" : $package;
	my $is_eval = (caller 2)[3];
	# the newline at the end of $@ (from $msg) suppresses additional info from die()
	$@ = "$subroutine:  ERROR in $filename at line $line$msg";

	if(defined $is_eval and $is_eval eq "(eval)")
	{	debug_end($debug) if defined $debug and $debug;
		die $@;
	} else
	{	#print $fh $@;
		debug_end($debug) if defined $debug and $debug;
		die $@;
	}
}

#-# =head2 sub try { .. } catch { .. }
#-# 
#-# A neat idea that doesn't work well as it is now.   Assignments don't
#-# work with in the try/catch anyhow.
#-# 
#-# From the perlsub(1) man page
#-# 
#-# =cut
#-# 
#-# sub try(&@) 
#-# {	my($code, $handler) = @_;
#-# 	eval { &$code };
#-# 	if ($@) 
#-# 	{	local $_ = $@;
#-# 		&$handler;
#-# 	}
#-# }
#-# sub catch(&)
#-# {	$_[0] 
#-# }
#-# 

1;

