package Globals;


# Copyright (c) 1999 Gabriel Deal. All rights reserved.
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.


$rballdir = 'rball';

# the rball directory as the web server sees it.
$this_dir = "/www02/d35/gabrielx/$rballdir";
$db_dir = "$this_dir/DB";
$log_file = "$this_dir/logs/joined.txt";

$description_db_name = 'description';
$save_db_name = 'save';
$ladder_db_name = 'ladder'; # followed by a number
$user_db_name = 'users';

$num_ladders = 3;
@ladder_names = ("The Masters", "The Tough", "The Pack");
$suffix = "";

$diff_limit = 2;
$uwirl_name = 'UWIRL';

# sillyness
@victory_phrases = (
	"defeated",
	"victored over",
	"beat",
	"prevailed in a match with",
	"crushed" # will hardly ever be used
);

$maintainer_email = 'gabrielx@u.washington.edu';

# must be after $uwirl_name and $maintainer_email...
$error = "<H1>$uwirl_name Error</H1>You can email $maintainer_email to report this, please include the error message below.<P>Error message:<Br>";

$base_url = "http://weber.u.washington.edu/~gabrielx/$rballdir";

$footer = qq!
<P>
<A Href="$base_url/html/">Main page</A>
<Br>
<A Href="$base_url/cgi/create_user.cgi">Create new user account</A>
<Br>
<A Href="$base_url/cgi/display_rankings.cgi">Display rankings</A>
<Br>
<A Href="$base_url/cgi/court_report.cgi">The court report</A>
<Br>
<A Href="$base_url/cgi/match_report.cgi">Report a match</A>
<Br>
<A Href="$base_url/cgi/modify_user.cgi">Modify user account</A>
<Br>
<A Href="$base_url/cgi/delete_user.cgi">Delete user account</A>
!;

# when adding columns, you may want to look at the check_*() functions
#
# codes:
#	#	used to keep the order
#	r	required
#	o	optional
#	w	required as input from web when creating
#	i	integer
%user_cols = (
	"name" => "1 rw",
	"affiliation" => "2 o",
	"department" => "3 o",
	"url" => "4 o",
	"passwd" => "5 rw",
	"ladder" => "6 rwi",
	"status" => "7 ri",
	"wins" => "8 ri",
	"losses" => "9 ri",
	"forfeit" => "10 ri",
	"create-info" => "11 r",
	"modify-info" => "12r",
	"phone" => "13 o",
	"rank" => "14 r"
);
%ladder_cols = (
	"rank" => "1 ri",
	"create-info" => "2 r",
	"modify-info" => "3 r"
);
%description_cols = (
	"event" => "1 ri",
	"description" => "2 o",
	"create-info" => "3 r",
	"modify-info" => "4 r"
);



1;
