package AsciiDB::TagRecord;

# Copyright (c) 1997,1998 Jose A. Rodriguez. All rights reserved.
# This program is free software; you can redistribute it and/or modify it
# under the same terms as Perl itself.


# April 22, 1999 modifications by Gabriel Deal to TagRecord.pm
#
#  * added EXISTS function
#  * added class name to fatal error messages
#  * packing and unpacking data so you can store data like keys to
#    fields in the field (users inputing "\n[wins]: 100" in say the
#    password field could modify the win field if the win field comes
#    before the password field in the db file).   This kind of breaks
#    the nice text files, but they're still plain text and are really
#    close to the data that they're actually storing.   modified sync()
#    and load().
#  * sync() replaced entries consisting of a zero with the empty
#    string:
#    print RECORD "[$fieldName]: ", ($self->{$fieldName} || ''), "\n";


require Tie::Hash;
@ISA = (Tie::Hash);

$VERSION = '1.00';

use Carp;

sub TIEHASH {
	my $class = shift;
	my %params = @_;

	my $self = {};
	$self->{_FILENAME} = $params{FILENAME};
	$self->{_SCHEMA} = $params{SCHEMA};
	$self->{_READONLY} = $params{READONLY};
	$self->{_FILEMODE} = $params{FILEMODE};
	$self->{_LOCK} = $params{LOCK};

	bless $self, $class;
}

sub FETCH {
	my ($self, $key) = @_;

	$self->load() unless exists $self->{_LOADED};

	return $self->{$key};	
}

sub STORE {
	my ($self, $key, $value) = @_;

	return if $self->{_READONLY};

	$self->load() unless 
		exists ($self->{_LOADED}) or (! -f $self->{_FILENAME});

	$self->{$key} = $value;
	$self->{_LOADED} = 1;
	$self->{_UPDATED} = 1;
}

sub FIRSTKEY {
	my $self = shift;
	
	my %schema = %{$self->{_SCHEMA}};
	my @iterator = @{$schema{ORDER}};
	$self->{_ITERATOR} = \@iterator;

	shift @{$self->{_ITERATOR}};
}

sub NEXTKEY {
	my $self = shift;
	
	shift @{$self->{_ITERATOR}};
}

sub EXISTS {
	my($self, $key) = @_;

	return 0 if ! -f $self->{_FILENAME};

	$self->load() unless exists $self->{_LOADED};

	exists $self->{$key} || 0;
}

sub DELETE {
	my ($self, $key) = @_;

	$self->load() unless exists $self->{_LOADED};

	delete $self->{$key};
	$self->{_UPDATED} = 1;
}

sub DESTROY {
	my $self = shift;

	$self->sync ();
}

sub load {
	my $self = shift;

	open (RECORD, $self->{_FILENAME})
		or croak ref($self) . ": Can't open $self->{_FILENAME} record";

	flock(RECORD, 1) if $self->{_LOCK}; # Get shared lock

	my $fieldName = '';
	my($line, $data, $tmpfield);
	while (defined ($line = <RECORD>)) {
		($tmpfield, $data) = ($line =~ /^\[(.+)\]: (.*)$/);
		if (defined $tmpfield) {
			$data = '' if ! defined $data;
			$fieldName = $tmpfield;
			$fieldName =~ s/\\n/\n/g;	# protect against newlines in keys
			$self->{$fieldName} = $data;
			next;
		}
		
		$line =~ s/ ( *\[)/$1/g;		# protect from bad end of key
		$line =~ s/\] ( *:)/\]$1/g;	# protect from bad start of key
		chomp $line;
		$self->{$fieldName} .= "\n$line";
	}

	flock(RECORD, 8) if $self->{_LOCK}; # Unlock file

	close (RECORD);

	$self->{_LOADED} = 1;
	delete $self->{_UPDATED};
}

sub deleteRecord {
	my $self = shift;

	$self->{_LOADED} = 1;
	$self->{_UPDATED} = 0;
}

sub sync {
	my $self = shift;

	return if $self->{_READONLY} || ! $self->{_UPDATED};

	open (RECORD, "> $$self{_FILENAME}")
		or croak ref($self) . ": Can't create $$self{_FILENAME} record";

	flock(RECORD, 2) if $self->{_LOCK}; # Get shared lock

	my %schema = %{$self->{_SCHEMA}};
	my($tmp, $fieldName);
	foreach $fieldName (@{$schema{ORDER}}) {
		($tmp = $fieldName) =~ s/\n/\\n/g;	# protect against newlines in keys
		print RECORD "[$tmp]: ";
		if(defined $self->{$fieldName}) {
			$tmp = $self->{$fieldName};	
			$tmp =~ s/( *\[)/ $1/g;		# protect from bad end of key
			$tmp =~ s/\]( *:)/\] $1/g;	# protect from bad start of key

			print RECORD "$tmp\n";
		} else {
			print RECORD "\n";
		}
	}

	flock(RECORD, 8) if $self->{_LOCK}; # Unlock file

	close (RECORD);

	if (defined $self->{_FILEMODE}) {
		chmod ($self->{_FILEMODE}, $self->{_FILENAME})
			or croak ref($self) . ": Can't chmod $$self{_FILENAME}";
	}

	delete $self->{_UPDATED};
}

1;
