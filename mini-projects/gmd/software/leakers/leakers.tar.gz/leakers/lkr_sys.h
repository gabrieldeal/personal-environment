#ifndef LKR_SYS_H
#define LKR_SYS_H

/* lkr_sys.h, header for used only by lkr.c.
 * Copyright (C) 2000 Gabriel M. Deal gmd@yellowleaf.org
 * See README and LICENSE for more information. */

#include <stdio.h>

/* ALLOC for malloc/calloc/realloc/fopen/..
 * ALLOC_F for fopen/fdopen
 * ALLOC_M (ALLOC Mystery) for lkr_register()
 * FREE for lkr_unregister/free/fclose 
 * FREE_F for fclose */
typedef enum { ALLOC, ALLOC_F, ALLOC_U, FREE, FREE_F } reg_t;

#ifndef __P
#	ifdef __STDC__
#		define __P(p) p
#	else
#		define __P(p) ()
#	endif /*__STDC__*/
#endif /*__P*/

void _lkr_logfile __P((void));
void _lkr_log __P((char *fun, unsigned long lineno, char *fname, 
	void *memaddr, reg_t type, size_t size));
void _lkr_err __P((char *msg, char *file, unsigned long lineno));

#undef malloc
#undef calloc
#undef realloc
#undef strdup
#undef free
#undef cfree
#undef fopen
#undef fdopen
#undef fclose

#endif
