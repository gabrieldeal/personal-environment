/* This file uses width 3 tabs.
 *
 * lkr.c, functions to insert into the user's source via lkr.h.
 * Copyright (C) 2000 Gabriel M. Deal gmd@yellowleaf.org
 * See README and LICENSE for more information. */

#include <errno.h>
#include <time.h>
#include <stdio.h>
#include "lkr.h"
#include "lkr_sys.h"

extern int	errno;

static char *DEF_LOGFILE = "LEAKER_LOG";
static FILE *Log = NULL;
static unsigned int Flags = 0;
static time_t Starttime = 0;

void
lkr_setlogfile(fname)
	__CONST char *fname;
{
	if(Log != NULL)
		fclose(Log);
	Log = fopen(fname, "w+");
	if(Log == NULL)
	{
		fprintf(stderr, "lkr_setlogfile() unable to open ``%s'': ", fname);
		perror(NULL);
		exit(1);
	}

#ifdef __STDC__
	fprintf(Log, 
		"# leakers log file. There are six kinds of lines in this file:\n"
		"# time:function:line:file:memaddr:A:size - malloc/calloc/realloc()\n"
		"# time:function:line:file:memaddr:a      - fopen/fdopen()\n"
		"# time:function:line:file:memaddr:F      - free/cfree()\n"
		"# time:function:line:file:memaddr:f      - fclose()\n"
		"# ERROR, message\n");
	fflush(Log);
#endif

}

void
_lkr_logfile __P((void))
{
	char	*logfile;

	if(Log == NULL)
	{
		logfile = getenv("LEAKER_LOG");
		lkr_setlogfile(logfile == NULL ? DEF_LOGFILE : logfile);
	}
}

void
_lkr_log(fun, lineno, fname, memaddr, type, size)
	char *fun;
	unsigned long lineno;
	char *fname;
	void *memaddr;
	reg_t type;
	size_t size;
{
	time_t	t;

	t = time(NULL);
	if(Starttime == 0)
		Starttime = t;

	_lkr_logfile();

	/* time:function:line:file:memloc:AaFfU[:sizealloc] */
	if(type == ALLOC || type == ALLOC_U)
		fprintf(Log, "%lu:%s:%lu:%s:%p:A:%lu\n", 
			(long unsigned) Starttime - t, fun, (long unsigned) lineno, 
			fname, memaddr, (long unsigned) size);
	else if(type == ALLOC_F)
		fprintf(Log, "%lu:%s:%lu:%s:%p:a\n", 
			(long unsigned) Starttime - t, fun, (long unsigned) lineno, 
			fname, memaddr);
	else if(type == FREE)
		fprintf(Log, "%lu:%s:%lu:%s:%p:F\n", 
			(long unsigned) Starttime - t, fun, (long unsigned) lineno, 
			fname, memaddr);
	else if(type == FREE_F)
		fprintf(Log, "%lu:%s:%lu:%s:%p:f\n", 
			(long unsigned) Starttime - t, fun, (long unsigned) lineno, 
			fname, memaddr);
		
	fflush(Log);
}

void*
lkr_register(ptr, fname, lineno)
	void *ptr;
	char *fname;
	unsigned long lineno;
{
	if(ptr == NULL)
		_lkr_err("unknown memory allocator returned NULL", fname, lineno);
	else
		_lkr_log("lkr_register", lineno, fname, ptr, 
			ALLOC_U, -1);

	return ptr;
}
void*
lkr_unregister(ptr, fname, lineno)
	void *ptr;
	char *fname;
	unsigned long lineno;
{
	_lkr_log("lkr_unregister", lineno, fname, ptr, FREE, -1);

	return ptr;
}

char*
lkr_strdup(ptr, fname, lineno)
	__CONST char *ptr;
	char *fname;
	unsigned long lineno;
{
	char	*ret;
	int	len;

	len = strlen(ptr) + 1;
	ret = malloc(len);
	if(ret == NULL)
		_lkr_err("strdup() returned NULL", fname, lineno);
	else
		_lkr_log("lkr_strdup", lineno, fname, (void*)ret, ALLOC, len);

	return strcpy(ret, ptr);
}

void*
lkr_malloc(size, fname, lineno)
	size_t size;
	char *fname;
	unsigned long lineno;
{
	void	*ret;

	ret = malloc(size);
	if(ret == NULL)
		_lkr_err("malloc() returned NULL", fname, lineno);
	else
		_lkr_log("lkr_malloc", lineno, fname, ret, ALLOC, size);

	return ret;
}

void*
lkr_calloc(nmemb, size, fname, lineno)
	size_t nmemb;
	size_t size;
	char *fname;
	unsigned long lineno;
{
	void	*ret;

	ret = calloc(nmemb, size);
	if(ret == NULL)
		_lkr_err("calloc() returned NULL", fname, lineno);
	else
		_lkr_log("lkr_calloc", lineno, fname, ret, ALLOC, size);

	return ret;
}

void*
lkr_realloc(ptr, size, fname, lineno)
	void *ptr;
	size_t size;
	char *fname;
	unsigned long lineno;
{
	void	*ret;

	ret = realloc(ptr, size);
	if(ret == NULL)
		_lkr_err("realloc() returned NULL", fname, lineno);
	else
	{
		_lkr_log("lkr_reallocfree", lineno, fname, ptr, FREE, -1);
		_lkr_log("lkr_realloc", lineno, fname, ret, ALLOC, size);
	}

	return ret;
}


FILE*
lkr_fdopen(fd, mode, fname, lineno)
	int fd;
	char *mode;
	char *fname;
	unsigned long lineno;
{
	FILE	*ret;

	ret = fdopen(fd, mode);
	if(ret == NULL)
		_lkr_err("fdopen() returned NULL", fname, lineno);
	else
		_lkr_log("lkr_fdopen", lineno, fname, (void*)ret, ALLOC_F, -1);

	return ret;
}

FILE*
lkr_fopen(name, mode, fname, lineno)
	char *name;
	char *mode;
	char *fname;
	unsigned long lineno;
{
	FILE	*ret;

	ret = fopen(name, mode);
	if(ret == NULL)
		_lkr_err("fopen() returned NULL", fname, lineno);
	else
		_lkr_log("lkr_fopen", lineno, fname, (void*)ret, ALLOC_F, -1);

	return ret;
}

int
lkr_fclose(ptr, fname, lineno)
	FILE *ptr;
	char *fname;
	unsigned long lineno;
{
	int	ret;

	ret = fclose(ptr);
	if(ret == EOF)
		_lkr_err("fclose() returned EOF", fname, lineno);
	if(ptr == NULL)
		_lkr_err("fclose() was passed a null FILE*", fname, lineno);
	_lkr_log("lkr_fclose", lineno, fname, (void*)ptr, FREE_F, -1);

	return ret;
}

void
lkr_free(ptr, fname, lineno)
	void *ptr;
	char *fname;
	unsigned long lineno;
{
	free(ptr);
	_lkr_log("lkr_free", lineno, fname, ptr, FREE, -1);
}

void
_lkr_err(msg, fname, lineno)
	char *msg;
	char *fname;
	unsigned long lineno;
{
	fprintf(Log, "ERROR, occurred at %s:%lu, %s\n", fname, lineno, msg);
	fflush(Log);
	if(Flags != LKR_IGNORE)
	{
		fprintf(stderr, "ERROR:  %s in %s at line %lu: ", msg, fname, lineno);
		perror(NULL);
		if(Flags == LKR_CROAK)
			abort();
	}
}
