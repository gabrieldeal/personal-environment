#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <lkr.h>

int
main __P((void))
{
	char	*strdup_f,
			*calloc_f,
			*malloc_f,
			*realloc_f;
	FILE	*fopen_f,
			*fdopen_f;
			

	strdup("asdf");
	strdup_f = strdup("asdf");
	calloc(10, 10);
	calloc_f = calloc(10, 10);
	malloc(10);
	malloc_f = malloc(10);
	realloc(malloc(10), 12);
	realloc_f = realloc(malloc(10), 12);
	fopen("/tmp/test.out1", "w+");
	fopen_f = fopen("/tmp/test.out2", "w+");
	fdopen(0, "r");
	fdopen_f = fdopen(1, "w");

	free(strdup_f);
	free(calloc_f);
	free(malloc_f);
	free(realloc_f);
	fclose(fopen_f);
	fclose(fdopen_f);

	free(realloc_f);
	free(0);
	fclose(fdopen_f);

	free(lkr_register(malloc(10), __FILE__, __LINE__));
	free(fopen("/tmp/test.out2", "r"));
	fclose(malloc(10));

	free(malloc(10));
	free(malloc(10));
	free(malloc(10));
	free(malloc(10));
	free(malloc(10));
	fclose(fopen("/tmp/test.out2", "r"));
	fclose(fopen("/tmp/test.out2", "r"));
	fclose(fopen("/tmp/test.out2", "r"));

	return 0;
}
