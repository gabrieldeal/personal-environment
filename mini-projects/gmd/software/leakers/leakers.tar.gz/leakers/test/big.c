#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <lkr.h>

int
main(argc, argv)
	int argc;
	char **argv;
{
	char	**a;
	int	slots,
			i;

	fopen("/etc/passwd", "r");

	if(argc != 2)
	{
		fprintf(stderr, "Bad arguments\n");
		exit(1);
	}
	slots = atoi(argv[1]);
	
	a = malloc(sizeof(char*)*slots);
	for(i = 0 ; i < slots ; i++)
		a[i] = malloc(1);	

	return 0;
}
