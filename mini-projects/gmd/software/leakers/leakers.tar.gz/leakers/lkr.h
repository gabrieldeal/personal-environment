#ifndef LEAKERS_H
#define LEAKERS_H

/* This file uses width 3 tabs.
 *
 * lkr.h, user function prototypes and macro definitions.
 * Copyright (C) 2000 Gabriel M. Deal gmd@yellowleaf.org
 * See README and LICENSE for more information.
 *
 * Perl POD documentation follows...

=head1 NAME

liblkrs - Detect memory allocation errors.

=head1 SYNOPSIS

#include <lkr.h>

void *B<lkr_malloc>(size_t size, char *fname, unsigned long lineno)

void *B<lkr_calloc>(size_t nmemb, size_t size, char *fname, unsigned long lineno)

void *B<lkr_realloc>(void *ptr, size_t size, char *fname, unsigned long lineno)

char *B<lkr_strdup>(const char *src, char *fname, unsigned long lineno)

void B<lkr_free>(void *ptr, char *fname, unsigned long lineno)

FILE *B<lkr_fopen>(char *path, char *mode, char *fname, unsigned long lineno)

FILE *B<lkr_fdopen>(int filedes, char *mode, char *fname, unsigned long lineno)

int B<lkr_fclose>(FILE *stream, char *fname, unsigned long lineno)

=head1 DESCRIPTION

To use B<liblkrs>, include F<lkr.h> in any C source file you wish to
debug.   B<liblkrs> works by using macros to replace calls in your
code with calls to one of the B<lkr_*()> functions listed above, so
including F<lkr.h> may be all you need to do.   If you are using
functions that B<liblkrs> doesn't know about, you may want to write
your own macros to wrap calls to those functions, for instance if
you're using GNU readline, this might be useful:

 #define readline(a) lkr_register(readline(a), __FILE__, __LINE__)

Once you've recompiled your code, run it as usual, and use B<leakers>
to examine the trace file B<liblkrs> wrote.

=head1 FUNCTIONS

=head2 void *lkr_register(void *ptr, char *filename, unsigned long linenum)

Register memory as allocated and return it.   Useful when
libraries you are linking against such as Readline allocates 
memory for you.   

I<ptr>:  the newly allocated memory.   I<filename>:  name of file where
lkr_register() memory was allocated (__FILE__).   I<linenum>:  line
number where memory was allocated (__LINE__).

Returns:  the return value is I<ptr>.

=head2 void *lkr_unregister(void *ptr, char *fname, unsigned long lineno)

Unregister memory.   Useful when you are passing memory you have
registered (using malloc/calloc/realloc or lkr_register) off to
another library to deallocate for you.

I<ptr>:  pointer to the memory you are about to deallocate.
I<fname>: filename where memory is being deallocated.   I<lineno>:
line number where memory is being deallocated.

Returns:  the return value is I<ptr>.

=head2 void lkr_setflags(unsigned int flags)

Set the error handling flags.   Use this to cause B<liblkrs> to print
a warning message to standard error or to dump core when an error is
detected.   Default is LKR_IGNORE.

I<flags>:  one of LKR_IGNORE, LKR_CROAK, or LKR_WARN

=head2 void lkr_setlogfile(const char *fname)

Use this function to change the log file name from the default
filename:  LEAKER_LOG.   The environment variable LEAKER_LOG can be
used to set this also.

=head1 AUTHOR

gabriel m. deal, gmd@yellowleaf.org, http://www.yellowleaf.org/gmd/software/leakers/

=cut

*/


 

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#ifndef __P
#	ifdef __STDC__
#		define __P(p) p
#	else
#		define __P(p) ()
#	endif /*__STDC__*/
#endif /*__P*/
#ifdef __STDC__
#	define __CONST const
#else
#	define __CONST
#endif

#define malloc(a) lkr_malloc(a, __FILE__, __LINE__)
#define calloc(a, b) lkr_calloc(a, b, __FILE__, __LINE__)
#define realloc(a, b) lkr_realloc(a, b, __FILE__, __LINE__)
#define strdup(a) lkr_strdup(a, __FILE__, __LINE__)
#define free(a) lkr_free(a, __FILE__, __LINE__)
#define cfree(a) lkr_free(a, __FILE__, __LINE__)
#define fopen(a, b) lkr_fopen(a, b, __FILE__, __LINE__)
#define fdopen(a, b) lkr_fdopen(a, b, __FILE__, __LINE__)
#define fclose(a) lkr_fclose(a, __FILE__, __LINE__)

void *lkr_unregister __P((void *ptr, char *fname, unsigned long lineno));
void *lkr_register __P((void *ptr, char *fname, unsigned long lineno));

void *lkr_malloc __P((size_t size, char *fname, unsigned long lineno));
void *lkr_calloc __P((size_t nmemb, size_t size, char *fname, unsigned long lineno));
void *lkr_realloc __P((void *ptr, size_t size, char *fname, unsigned long lineno));
char *lkr_strdup __P((const char *src, char *fname, unsigned long lineno));
void lkr_free __P((void *ptr, char *fname, unsigned long lineno));
FILE *lkr_fopen __P((char *path, char *mode, char *fname, unsigned long lineno));
FILE *lkr_fdopen __P((int filedes, char *mode, char *fname, unsigned long lineno));
int lkr_fclose __P((FILE *stream, char *fname, unsigned long lineno));

/* Log File Format
 * Each call to a lkr_*() function (except lkr_setflags()) will write
 * at least one line to the log file in this format:
 * timestamp:function:line:file:memlocation:R:sizeallocated
 * timestamp:function:line:file:memlocation:U:
 * Timestamp is for curiosity only, it's the offset in seconds since
 * the first leaker function call. */
void lkr_setlogfile __P((const char *fname));

/** Set the error handling flags.
  * @param flags one of LKR_IGNORE, LKR_CROAK, or LKR_WARN */
void lkr_setflags __P((unsigned int flags));

/** Ignore errors (act just like default behavior). */
#define LKR_IGNORE 0
/** Write to stderr and then abort() on errors. */
#define LKR_CROAK 1
/** Write to stderr about errors. */
#define LKR_WARN 2

#endif
